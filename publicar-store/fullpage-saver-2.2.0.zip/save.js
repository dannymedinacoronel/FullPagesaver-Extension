const params = new URLSearchParams(location.search);
const TARGET_TAB_ID = Number(params.get("tab"));
const MODE = params.get("mode") || "html";
const PAPER = params.get("paper") || "A4";
const ORIENTATION = params.get("orientation") || "portrait";
const status = document.querySelector("#status");
const MAX_CAPTURES = 120;
const SCROLL_STEP = 0.8;
const SCROLL_SETTLE_MS = 900;
const END_STABILITY_PASSES = 3;

const PAPER_SIZES = {
  A4: [210, 297],
  Letter: [215.9, 279.4],
  A3: [297, 420],
  Legal: [215.9, 355.6]
};

function setStatus(message, isError = false) {
  status.textContent = message;
  status.dataset.error = String(isError);
}

function safeFileName(value) {
  const cleaned = value
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, "_")
    .replace(/[. ]+$/g, "")
    .trim()
    .slice(0, 150);
  return cleaned || "pagina-web";
}

async function getTargetTab() {
  const tab = await chrome.tabs.get(TARGET_TAB_ID);
  if (!tab?.id) {
    throw new Error(t("err.tabNotFound"));
  }
  if (!/^https?:\/\//i.test(tab.url || "")) {
    throw new Error(t("err.httpOnly"));
  }
  return tab;
}

async function readPageMetrics(tabId) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const root = document.scrollingElement || document.documentElement;
      const viewport = { left: 0, top: 0, right: window.innerWidth, bottom: window.innerHeight };

      // Rectángulo visible del elemento en coordenadas de la pestaña: suma el
      // desplazamiento de los iframes y recorta por los ancestros con overflow.
      const visibleRect = (element, frame) => {
        const view = element.ownerDocument.defaultView;
        const rect = element.getBoundingClientRect();
        let left = Math.max(frame.clip.left, frame.offsetX + rect.left);
        let top = Math.max(frame.clip.top, frame.offsetY + rect.top);
        let right = Math.min(frame.clip.right, frame.offsetX + rect.right);
        let bottom = Math.min(frame.clip.bottom, frame.offsetY + rect.bottom);
        for (let ancestor = element.parentElement; ancestor && right > left && bottom > top; ancestor = ancestor.parentElement) {
          const style = view.getComputedStyle(ancestor);
          if (/(hidden|clip|auto|scroll)/.test(`${style.overflowX} ${style.overflowY}`)) {
            const ancestorRect = ancestor.getBoundingClientRect();
            left = Math.max(left, frame.offsetX + ancestorRect.left);
            top = Math.max(top, frame.offsetY + ancestorRect.top);
            right = Math.min(right, frame.offsetX + ancestorRect.right);
            bottom = Math.min(bottom, frame.offsetY + ancestorRect.bottom);
          }
        }
        return { left, top, right, bottom };
      };

      // Documento principal más los iframes del mismo origen (visores PDF.js
      // y similares meten el área desplazable dentro de iframes anidados).
      const frames = [];
      const visitFrame = frame => {
        frames.push(frame);
        Array.from(frame.doc.querySelectorAll("iframe, frame")).forEach((element, index) => {
          let inner = null;
          try {
            inner = element.contentDocument;
          } catch {}
          if (!inner?.documentElement) return;
          const clip = visibleRect(element, frame);
          if (clip.right - clip.left < 100 || clip.bottom - clip.top < 100) return;
          const rect = element.getBoundingClientRect();
          visitFrame({
            doc: inner,
            path: [...frame.path, index],
            offsetX: frame.offsetX + rect.left + element.clientLeft,
            offsetY: frame.offsetY + rect.top + element.clientTop,
            clip
          });
        });
      };
      visitFrame({ doc: document, path: [], offsetX: 0, offsetY: 0, clip: viewport });

      const candidates = [];
      for (const frame of frames) {
        const view = frame.doc.defaultView;
        for (const element of frame.doc.querySelectorAll("body *")) {
          if (["select", "textarea", "option", "iframe", "frame"].includes(element.localName)) continue;
          if (element.clientHeight <= 100 || element.scrollHeight <= element.clientHeight + 8) continue;
          if (element.clientWidth / Math.max(1, element.clientHeight) <= 0.45) continue;
          if (!/auto|scroll|overlay/.test(view.getComputedStyle(element).overflowY)) continue;
          // Recorta al área de contenido para no capturar las barras de scroll.
          const visible = visibleRect(element, frame);
          const box = element.getBoundingClientRect();
          visible.right = Math.min(visible.right, frame.offsetX + box.left + element.clientLeft + element.clientWidth);
          visible.bottom = Math.min(visible.bottom, frame.offsetY + box.top + element.clientTop + element.clientHeight);
          const width = visible.right - visible.left;
          const height = visible.bottom - visible.top;
          if (width <= 100 || height <= 100) continue;
          candidates.push({ element, frame, visible, area: width * height });
        }
      }
      // Entre las áreas grandes se prefiere la más anidada: un visor dentro de
      // un iframe es el contenido real aunque la página tenga otro contenedor.
      const largest = Math.max(0, ...candidates.map(candidate => candidate.area));
      candidates.sort((first, second) => {
        const firstMain = first.area >= largest * 0.5;
        const secondMain = second.area >= largest * 0.5;
        if (firstMain !== secondMain) return firstMain ? -1 : 1;
        if (firstMain && first.frame.path.length !== second.frame.path.length) {
          return second.frame.path.length - first.frame.path.length;
        }
        return second.area - first.area;
      });

      const chosen = candidates[0];
      const target = chosen ? chosen.element : root;
      let selector = "";

      if (chosen) {
        const parts = [];
        let current = target;
        while (current && current !== chosen.frame.doc.documentElement) {
          if (current.id) {
            parts.unshift(`#${CSS.escape(current.id)}`);
            break;
          }
          const sameTag = Array.from(current.parentElement?.children || [])
            .filter(sibling => sibling.localName === current.localName);
          const position = sameTag.indexOf(current) + 1;
          parts.unshift(`${current.localName}:nth-of-type(${position})`);
          current = current.parentElement;
        }
        selector = parts.join(" > ");
      }

      const { left, top, right, bottom } = chosen ? chosen.visible : viewport;

      return {
        title: document.title,
        selector,
        framePath: chosen ? chosen.frame.path : [],
        isDocument: !chosen,
        layoutViewportWidth: window.innerWidth,
        viewportWidth: Math.max(0, right - left),
        viewportHeight: Math.max(0, bottom - top),
        cropLeft: left,
        cropTop: top,
        clientHeight: target.clientHeight,
        documentHeight: target.scrollHeight,
        scrollY: chosen ? target.scrollTop : window.scrollY
      };
    }
  });
  if (!result?.result?.viewportWidth || !result.result.viewportHeight || !result.result.documentHeight) {
    throw new Error(t("err.noScrollArea"));
  }
  return result.result;
}

function sameScrollTarget(first, second) {
  return first.selector === second.selector
    && first.isDocument === second.isDocument
    && first.framePath.join("/") === second.framePath.join("/");
}

async function scrollPage(tabId, metrics, y) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (selector, isDocument, requestedY, framePath) => {
      if (isDocument) {
        const root = document.scrollingElement || document.documentElement;
        const documentElement = document.documentElement;
        const body = document.body;
        const originalRootBehavior = root.style.scrollBehavior;
        const originalHtmlBehavior = documentElement.style.scrollBehavior;
        const originalBodyBehavior = body?.style.scrollBehavior;
        root.style.scrollBehavior = "auto";
        documentElement.style.scrollBehavior = "auto";
        if (body) body.style.scrollBehavior = "auto";
        window.scrollTo(0, requestedY);
        const actualY = window.scrollY;
        root.style.scrollBehavior = originalRootBehavior;
        documentElement.style.scrollBehavior = originalHtmlBehavior;
        if (body) body.style.scrollBehavior = originalBodyBehavior;
        return actualY;
      }
      let doc = document;
      for (const index of framePath) {
        const frame = doc.querySelectorAll("iframe, frame")[index];
        try {
          doc = frame?.contentDocument;
        } catch {
          doc = null;
        }
        if (!doc) return null;
      }
      const element = doc.querySelector(selector);
      if (!element) return null;
      const originalBehavior = element.style.scrollBehavior;
      element.style.scrollBehavior = "auto";
      element.scrollTop = requestedY;
      const actualY = element.scrollTop;
      element.style.scrollBehavior = originalBehavior;
      return actualY;
    },
    args: [metrics.selector, metrics.isDocument, y, metrics.framePath]
  });
  if (typeof result?.result !== "number") {
    throw new Error(t("err.scrollFailed"));
  }
  return result.result;
}

// Oculta (o vuelve a mostrar) los elementos fijos o pegajosos que quedan
// encima del área capturada: cabeceras, barras y botones flotantes saldrían
// repetidos en cada captura como franjas en el PDF.
async function setOverlaysHidden(tabId, metrics, hidden) {
  await chrome.scripting.executeScript({
    target: { tabId },
    func: (framePath, selector, hide, crop) => {
      const chain = [];
      let doc = document;
      let offsetX = 0;
      let offsetY = 0;
      for (let level = 0; doc; level++) {
        const frame = level < framePath.length ? doc.querySelectorAll("iframe, frame")[framePath[level]] : null;
        chain.push({ doc, frame, offsetX, offsetY });
        if (!frame) break;
        const rect = frame.getBoundingClientRect();
        offsetX += rect.left + frame.clientLeft;
        offsetY += rect.top + frame.clientTop;
        try {
          doc = frame.contentDocument;
        } catch {
          doc = null;
        }
      }

      for (const { doc: current, frame, offsetX: x, offsetY: y } of chain) {
        if (!hide) {
          current.querySelectorAll("[data-fps-hidden]").forEach(element => {
            const previous = element.getAttribute("data-fps-hidden");
            element.style.removeProperty("visibility");
            if (previous) element.style.setProperty("visibility", previous.split("|")[0], previous.split("|")[1] || "");
            element.removeAttribute("data-fps-hidden");
          });
          continue;
        }
        const view = current.defaultView;
        const inner = frame || (selector ? current.querySelector(selector) : null);
        for (const element of current.querySelectorAll("body *")) {
          if (!/fixed|sticky/.test(view.getComputedStyle(element).position)) continue;
          if (inner && element.contains(inner)) continue;
          const rect = element.getBoundingClientRect();
          if (rect.width < 1 || rect.height < 1) continue;
          const overlaps = x + rect.left < crop.right && x + rect.right > crop.left
            && y + rect.top < crop.bottom && y + rect.bottom > crop.top;
          if (!overlaps) continue;
          // Si el elemento contiene el área que se recorre, no es una barra.
          if (rect.height >= (crop.bottom - crop.top) * 0.9 && rect.width >= (crop.right - crop.left) * 0.9) continue;
          const previous = element.style.getPropertyValue("visibility");
          element.setAttribute("data-fps-hidden", previous ? `${previous}|${element.style.getPropertyPriority("visibility")}` : "");
          element.style.setProperty("visibility", "hidden", "important");
        }
      }
    },
    args: [metrics.framePath, metrics.selector, hidden, {
      left: metrics.cropLeft,
      top: metrics.cropTop,
      right: metrics.cropLeft + metrics.viewportWidth,
      bottom: metrics.cropTop + metrics.viewportHeight
    }]
  });
}

function delay(milliseconds) {
  return new Promise(resolve => window.setTimeout(resolve, milliseconds));
}

async function captureFullPage(tab) {
  const initialMetrics = await readPageMetrics(tab.id);
  let metrics = initialMetrics;
  let documentHeight = initialMetrics.documentHeight;
  let lastPosition = -1;
  let nextPosition = 0;
  let stableAtEndPasses = 0;
  let stalledPasses = 0;
  const captures = [];

  try {
    while (true) {
      if (captures.length >= MAX_CAPTURES) {
        throw new Error(t("err.tooLong", { max: MAX_CAPTURES }));
      }

      const maximumScroll = Math.max(
        0,
        documentHeight - (metrics.isDocument ? metrics.viewportHeight : metrics.clientHeight)
      );
      const requestedPosition = Math.min(nextPosition, maximumScroll);
      const scrollY = await scrollPage(tab.id, metrics, requestedPosition);
      setStatus(t("status.capturing", { n: captures.length + 1 }));
      await delay(SCROLL_SETTLE_MS);

      const screenshotUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
        format: "png"
      });
      if (!screenshotUrl?.startsWith("data:image/")) {
        throw new Error(t("err.noScreenshot"));
      }

      const dataUrl = await cropCapture(
        screenshotUrl,
        metrics,
        metrics.layoutViewportWidth
      );
      captures.push({ dataUrl, scrollY });
      // Las barras fijas salen solo en la primera captura.
      if (captures.length === 1) await setOverlaysHidden(tab.id, metrics, true);

      const updatedMetrics = await readPageMetrics(tab.id);
      if (!sameScrollTarget(updatedMetrics, initialMetrics)) {
        throw new Error(t("err.areaChanged"));
      }

      const previousHeight = documentHeight;
      documentHeight = Math.max(documentHeight, updatedMetrics.documentHeight);
      metrics = updatedMetrics;
      const scrollableHeight = metrics.isDocument
        ? metrics.viewportHeight
        : metrics.clientHeight;
      const currentMaximum = Math.max(0, documentHeight - scrollableHeight);
      const isAtEnd = scrollY >= currentMaximum - 2;
      if (scrollY === lastPosition && !isAtEnd) {
        stalledPasses++;
      } else {
        stalledPasses = 0;
      }
      if (stalledPasses >= 3) {
        throw new Error(t("err.stalled"));
      }
      lastPosition = scrollY;

      if (isAtEnd && documentHeight === previousHeight) {
        stableAtEndPasses++;
      } else {
        stableAtEndPasses = 0;
      }

      if (stableAtEndPasses >= END_STABILITY_PASSES) break;

      if (isAtEnd) {
        await delay(SCROLL_SETTLE_MS);
        const settledMetrics = await readPageMetrics(tab.id);
        if (!sameScrollTarget(settledMetrics, initialMetrics)) {
          throw new Error(t("err.areaChangedLoading"));
        }
        metrics = settledMetrics;
        documentHeight = Math.max(documentHeight, settledMetrics.documentHeight);
        nextPosition = Math.min(
          documentHeight,
          scrollY + metrics.viewportHeight * SCROLL_STEP
        );
      } else {
        nextPosition = scrollY + metrics.viewportHeight * SCROLL_STEP;
      }
    }
  } finally {
    await setOverlaysHidden(tab.id, initialMetrics, false);
    await scrollPage(tab.id, initialMetrics, initialMetrics.scrollY);
  }

  return {
    captures,
    title: initialMetrics.title,
    viewportWidth: initialMetrics.viewportWidth,
    documentHeight,
    layoutViewportWidth: initialMetrics.layoutViewportWidth
  };
}

async function cropCapture(screenshotUrl, metrics, layoutViewportWidth) {
  const image = await loadCapture(screenshotUrl);
  const scale = image.naturalWidth / layoutViewportWidth;
  const left = Math.max(0, Math.round(metrics.cropLeft * scale));
  const top = Math.max(0, Math.round(metrics.cropTop * scale));
  const width = Math.min(
    image.naturalWidth - left,
    Math.round(metrics.viewportWidth * scale)
  );
  const height = Math.min(
    image.naturalHeight - top,
    Math.round(metrics.viewportHeight * scale)
  );
  if (!width || !height) {
    throw new Error(t("err.notVisible"));
  }
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d", { alpha: false });
  if (!context) {
    throw new Error(t("err.crop"));
  }
  context.drawImage(image, left, top, width, height, 0, 0, width, height);
  // Sin pérdida: el JPEG se aplica una sola vez al componer cada hoja; si se
  // comprime también aquí se notan las uniones entre capturas.
  return canvas.toDataURL("image/png");
}

async function loadCapture(dataUrl) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error(t("err.readCapture")));
    image.src = dataUrl;
  });
}

function canvasToJpegBytes(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(async blob => {
      if (!blob) {
        reject(new Error(t("err.compress")));
        return;
      }
      try {
        resolve(new Uint8Array(await blob.arrayBuffer()));
      } catch (error) {
        reject(error);
      }
    }, "image/jpeg", 0.86);
  });
}

async function makePdfPage(captures, pageIndex, pageHeight, documentHeight) {
  const width = captures[0].image.naturalWidth;
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = pageHeight;
  const context = canvas.getContext("2d", { alpha: false });
  if (!context) {
    throw new Error(t("err.pdfPage"));
  }
  context.fillStyle = "#fff";
  context.fillRect(0, 0, canvas.width, canvas.height);

  const pageStart = pageIndex * pageHeight;
  const pageEnd = Math.min(pageStart + pageHeight, documentHeight);
  for (const capture of captures) {
    const captureStart = Math.round(capture.scrollY * capture.scale);
    const captureEnd = captureStart + capture.image.naturalHeight;
    const overlapStart = Math.max(pageStart, captureStart);
    const overlapEnd = Math.min(pageEnd, captureEnd);
    if (overlapEnd <= overlapStart) continue;

    const sourceY = overlapStart - captureStart;
    const destinationY = overlapStart - pageStart;
    const segmentHeight = overlapEnd - overlapStart;
    context.drawImage(
      capture.image,
      0,
      sourceY,
      width,
      segmentHeight,
      0,
      destinationY,
      width,
      segmentHeight
    );
  }

  return canvasToJpegBytes(canvas);
}

function encodeText(value) {
  return new TextEncoder().encode(value);
}

// Cada página puede traer su propio tamaño en puntos (pageWidthPt/pageHeightPt);
// si no, se usa el papel elegido.
function createPdfBlob(jpegPages, pageWidthMm, pageHeightMm) {
  const pageCount = jpegPages.length;
  const objectCount = 2 + pageCount * 3;
  const objects = new Array(objectCount + 1);

  objects[1] = { parts: [encodeText("<< /Type /Catalog /Pages 2 0 R >>")] };
  objects[2] = {
    parts: [
      encodeText(
        `<< /Type /Pages /Kids [${jpegPages.map((_, index) => `${3 + index * 3} 0 R`).join(" ")}] /Count ${pageCount} >>`
      )
    ]
  };

  jpegPages.forEach((jpeg, index) => {
    const pageWidthPt = jpeg.pageWidthPt || pageWidthMm * 72 / 25.4;
    const pageHeightPt = jpeg.pageHeightPt || pageHeightMm * 72 / 25.4;
    const pageObjectId = 3 + index * 3;
    const imageObjectId = pageObjectId + 1;
    const contentObjectId = pageObjectId + 2;
    objects[pageObjectId] = {
      parts: [
        encodeText(
          `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidthPt.toFixed(3)} ${pageHeightPt.toFixed(3)}] /Resources << /XObject << /Im0 ${imageObjectId} 0 R >> >> /Contents ${contentObjectId} 0 R >>`
        )
      ]
    };
    objects[imageObjectId] = {
      parts: [
        encodeText(
          `<< /Type /XObject /Subtype /Image /Width ${jpeg.width} /Height ${jpeg.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.bytes.length} >>\nstream\n`
        ),
        jpeg.bytes,
        encodeText("\nendstream")
      ]
    };
    // Una página con tamaño propio se llena entera: el redondeo del canvas
    // dejaría una línea blanca abajo.
    const imageHeightPt = jpeg.pageHeightPt || pageWidthPt * jpeg.height / jpeg.width;
    const content = encodeText(
      `q\n${pageWidthPt.toFixed(3)} 0 0 ${imageHeightPt.toFixed(3)} 0 ${(pageHeightPt - imageHeightPt).toFixed(3)} cm\n/Im0 Do\nQ`
    );
    objects[contentObjectId] = {
      parts: [
        encodeText(`<< /Length ${content.length} >>\nstream\n`),
        content,
        encodeText("\nendstream")
      ]
    };
  });

  const chunks = [encodeText("%PDF-1.4\n")];
  const offsets = new Array(objectCount + 1).fill(0);
  let byteOffset = chunks[0].length;
  for (let id = 1; id <= objectCount; id++) {
    offsets[id] = byteOffset;
    const objectParts = [
      encodeText(`${id} 0 obj\n`),
      ...objects[id].parts,
      encodeText("\nendobj\n")
    ];
    chunks.push(...objectParts);
    byteOffset += objectParts.reduce((total, part) => total + part.length, 0);
  }

  const xrefOffset = byteOffset;
  let xref = `xref\n0 ${objectCount + 1}\n0000000000 65535 f \n`;
  for (let id = 1; id <= objectCount; id++) {
    xref += `${String(offsets[id]).padStart(10, "0")} 00000 n \n`;
  }
  xref += `trailer\n<< /Size ${objectCount + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;
  chunks.push(encodeText(xref));
  return new Blob(chunks, { type: "application/pdf" });
}

// ---------- Visores de páginas (PDF.js y similares) ----------

// Se inyecta en la página. Busca las páginas del visor dentro del área
// desplazable elegida. Con pageIndex = -1 solo las cuenta; si no, lleva esa
// página a la vista, espera a que se pinte y devuelve su canvas como JPEG.
async function viewerPageInTab(selector, framePath, pageIndex) {
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  let doc = document;
  for (const index of framePath) {
    let next = null;
    try {
      next = doc.querySelectorAll("iframe, frame")[index]?.contentDocument;
    } catch {}
    if (!next) return null;
    doc = next;
  }
  const container = selector ? doc.querySelector(selector) : doc.body;
  if (!container) return null;
  const pages = Array.from(container.querySelectorAll("[data-page-number]")).filter(page =>
    !page.closest(".thumbnail, #thumbnailView, #sidebarContainer")
    && !page.parentElement?.closest("[data-page-number]")
    && (page.classList.contains("page") || page.querySelector("canvas")));
  if (pageIndex < 0) return { count: pages.length };

  const page = pages[pageIndex];
  if (!page) return null;
  page.scrollIntoView({ block: "start" });
  let canvas = null;
  for (const deadline = Date.now() + 20_000; Date.now() < deadline;) {
    await sleep(250);
    const candidate = page.querySelector(".canvasWrapper canvas") || page.querySelector("canvas");
    const loaded = !page.classList.contains("page") || page.getAttribute("data-loaded") === "true";
    if (candidate?.width && candidate.height && loaded) {
      canvas = candidate;
      break;
    }
  }
  if (!canvas) return { error: "not-painted" };
  await sleep(150);

  // PDF.js deja el tamaño original de la página (en puntos) en su estilo:
  // "width: round(down, var(--total-scale-factor) * 595.27557px, ...)".
  const sizes = Array.from((page.getAttribute("style") || "").matchAll(/\*\s*([\d.]+)px/g), match => Number(match[1]));
  // Fondo blanco por si el canvas tiene zonas transparentes.
  const flat = doc.createElement("canvas");
  flat.width = canvas.width;
  flat.height = canvas.height;
  const context = flat.getContext("2d");
  context.fillStyle = "#fff";
  context.fillRect(0, 0, flat.width, flat.height);
  try {
    context.drawImage(canvas, 0, 0);
    return {
      dataUrl: flat.toDataURL("image/jpeg", 0.92),
      width: canvas.width,
      height: canvas.height,
      widthPt: sizes.length >= 2 ? sizes[0] : null,
      heightPt: sizes.length >= 2 ? sizes[1] : null
    };
  } catch {
    return { error: "tainted" };
  }
}

// Códigos de error que devuelve viewerPageInTab (se ejecuta en la página y no
// tiene acceso a las traducciones).
const VIEWER_ERRORS = { "not-painted": "err.viewerNotPainted", tainted: "err.viewerTainted" };

async function runViewerPage(tabId, metrics, pageIndex) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    func: viewerPageInTab,
    args: [metrics.selector, metrics.framePath, pageIndex]
  });
  return result?.result;
}

// Si el área desplazable es un visor de páginas, cada página del PDF se saca
// de su propio canvas: misma nitidez que en pantalla, sin uniones ni barras.
async function captureViewerPages(tab) {
  const metrics = await readPageMetrics(tab.id);
  const info = await runViewerPage(tab.id, metrics, -1);
  if (!info?.count) return null;

  const pages = [];
  try {
    for (let index = 0; index < info.count; index++) {
      setStatus(t("status.viewerCopying", { n: index + 1, total: info.count }));
      const page = await runViewerPage(tab.id, metrics, index);
      if (!page?.dataUrl) {
        throw new Error(t("err.viewerPage", { n: index + 1, reason: t(VIEWER_ERRORS[page?.error] || "err.viewerUnreadable") }));
      }
      pages.push(page);
    }
  } finally {
    await scrollPage(tab.id, metrics, metrics.scrollY);
  }
  return { pages, title: metrics.title };
}

function dataUrlToBytes(dataUrl) {
  const binary = atob(dataUrl.slice(dataUrl.indexOf(",") + 1));
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index++) {
    bytes[index] = binary.charCodeAt(index);
  }
  return bytes;
}

function createViewerPdf(pages) {
  const [paperWidthMm] = PAPER_SIZES[PAPER] || PAPER_SIZES.A4;
  const paperWidthPt = paperWidthMm * 72 / 25.4;
  return createPdfBlob(pages.map(page => {
    const pageWidthPt = page.widthPt || paperWidthPt;
    return {
      width: page.width,
      height: page.height,
      bytes: dataUrlToBytes(page.dataUrl),
      pageWidthPt,
      pageHeightPt: page.heightPt || pageWidthPt * page.height / page.width
    };
  }), paperWidthMm, paperWidthMm);
}

async function createPdf(captureResult, orientation) {
  if (!captureResult.captures.length) {
    throw new Error(t("err.noCaptures"));
  }

  setStatus(t("status.preparingCaptures"));
  const captures = [];
  for (const capture of captureResult.captures) {
    const image = await loadCapture(capture.dataUrl);
    captures.push({
      ...capture,
      image,
      scale: image.naturalWidth / captureResult.viewportWidth
    });
  }

  const paper = PAPER;
  const [shortSide, longSide] = PAPER_SIZES[paper] || PAPER_SIZES.A4;
  const pageWidthMm = orientation === "landscape" ? longSide : shortSide;
  const pageHeightMm = orientation === "landscape" ? shortSide : longSide;
  const pixelsPerCssPixel = captures[0].scale;
  const pageHeightPx = Math.ceil(
    captures[0].image.naturalWidth * pageHeightMm / pageWidthMm
  );
  const documentHeightPx = Math.ceil(
    captureResult.documentHeight * pixelsPerCssPixel
  );
  const pageCount = Math.max(1, Math.ceil(documentHeightPx / pageHeightPx));
  const jpegPages = [];

  for (let index = 0; index < pageCount; index++) {
    setStatus(t("status.composing", { n: index + 1, total: pageCount }));
    const pageRasterHeight = Math.min(
      pageHeightPx,
      documentHeightPx - index * pageHeightPx
    );
    jpegPages.push({
      width: captures[0].image.naturalWidth,
      height: pageRasterHeight,
      bytes: await makePdfPage(captures, index, pageRasterHeight, documentHeightPx)
    });
  }

  return createPdfBlob(jpegPages, pageWidthMm, pageHeightMm);
}

// ---------- Preparación: abrir menús y recorrer hasta el final ----------

// Se inyecta en la página. Abre desplegables/acordeones y baja hasta el final
// para forzar la carga diferida; después vuelve arriba.
async function preparePageInTab() {
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const clicked = new WeakSet();

  const expand = () => {
    let opened = 0;
    document.querySelectorAll("details:not([open])").forEach(element => {
      element.open = true;
      opened++;
    });
    document.querySelectorAll(".collapse:not(.show)").forEach(element => {
      element.classList.add("show");
      opened++;
    });
    document.querySelectorAll('[aria-expanded="false"]').forEach(element => {
      if (clicked.has(element)) return;
      if (element.matches("select, input, textarea, [role=combobox]")) return;
      const link = element.closest("a[href]");
      if (link && !/^(#|javascript:)/i.test(link.getAttribute("href") || "")) return;
      if (element.closest("form") && element.matches("button[type=submit], button:not([type])") && !element.hasAttribute("aria-controls")) return;
      clicked.add(element);
      try {
        element.click();
        opened++;
      } catch {}
    });
    return opened;
  };

  // Incluye los iframes del mismo origen: visores como PDF.js solo pintan las
  // páginas que llegan a verse dentro de su contenedor desplazable.
  const scrollTargets = () => {
    const root = document.scrollingElement || document.documentElement;
    const inner = [];
    const visit = doc => {
      const view = doc.defaultView;
      for (const element of doc.querySelectorAll("body *")) {
        if (element.localName === "iframe" || element.localName === "frame") {
          let frameDoc = null;
          try {
            frameDoc = element.contentDocument;
          } catch {}
          if (frameDoc?.documentElement) visit(frameDoc);
          continue;
        }
        if (/auto|scroll|overlay/.test(view.getComputedStyle(element).overflowY)
          && element.scrollHeight > element.clientHeight + 8
          && element.clientHeight > 100) {
          inner.push(element);
        }
      }
    };
    visit(document);
    return [root, ...inner];
  };

  const scrollToEnd = async (element, deadline) => {
    let stable = 0;
    let lastHeight = -1;
    while (stable < 3 && Date.now() < deadline) {
      const step = Math.max(200, (element.clientHeight || innerHeight) * 0.8);
      element.scrollTop = Math.min(element.scrollTop + step, element.scrollHeight);
      await sleep(350);
      const atEnd = element.scrollTop + element.clientHeight >= element.scrollHeight - 2;
      if (atEnd && element.scrollHeight === lastHeight) stable++;
      else stable = atEnd ? 1 : 0;
      lastHeight = element.scrollHeight;
    }
    element.scrollTop = 0;
  };

  const deadline = Date.now() + 90_000;
  for (let round = 0; round < 4; round++) {
    const opened = expand();
    await sleep(500);
    for (const element of scrollTargets()) {
      await scrollToEnd(element, deadline);
    }
    if (!opened && round > 0) break;
  }
  window.scrollTo(0, 0);
  await sleep(400);
  return true;
}

async function preparePage(tabId) {
  setStatus(t("status.preparing"));
  await chrome.scripting.executeScript({ target: { tabId }, func: preparePageInTab });
}

// ---------- Copia HTML autocontenida ----------

// Se inyecta en la página. Igual que SavePage WE, copia también el contenido
// de los iframes del mismo origen (como srcdoc) y guarda cada canvas como
// imagen de fondo. Devuelve un documento por marco: el 0 es la página y los
// demás se referencian como "fps-frame:N". Los recursos van marcados como
// "fps-res:N" y las hojas externas que no se pudieron leer como "fps-css:N".
async function snapshotPageInTab() {
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const urls = [];
  const index = new Map();
  const externalCss = [];
  const token = (value, base) => {
    let absolute;
    try {
      absolute = new URL(value, base).href;
    } catch {
      return value;
    }
    if (!/^https?:/i.test(absolute)) return absolute;
    if (!index.has(absolute)) {
      index.set(absolute, urls.length);
      urls.push(absolute);
    }
    return `fps-res:${index.get(absolute)}`;
  };
  const cssUrls = (text, base) => text.replace(
    /url\(\s*(['"]?)([^'")]+)\1\s*\)/g,
    (match, quote, value) => (/^(data|blob|#)/i.test(value.trim()) ? match : `url("${token(value.trim(), base)}")`)
  );
  // Los marcos tienen sus propias clases CSSImportRule, por eso no se usa instanceof.
  const sheetText = (sheet, base) => Array.from(sheet.cssRules).map(rule => {
    if (rule.constructor.name === "CSSImportRule" && rule.styleSheet) {
      try {
        return sheetText(rule.styleSheet, rule.styleSheet.href || base);
      } catch {
        return rule.cssText;
      }
    }
    return cssUrls(rule.cssText, base);
  }).join("\n");
  const safeCss = text => text.replace(/<\/style/gi, "<\\/style");
  const frameDocument = frame => {
    try {
      const doc = frame.contentDocument;
      return doc?.documentElement ? doc : null;
    } catch {
      return null;
    }
  };
  const allDocuments = (doc = document, list = []) => {
    list.push(doc);
    doc.querySelectorAll("iframe, frame").forEach(frame => {
      const inner = frameDocument(frame);
      if (inner) allDocuments(inner, list);
    });
    return list;
  };
  const canvasImage = canvas => {
    try {
      return canvas.width && canvas.height ? canvas.toDataURL("image/png") : null;
    } catch {
      return null;
    }
  };

  // Los visores tipo PDF.js solo mantienen pintadas las páginas cercanas a la
  // vista. Se recorre cada visor y se guarda la imagen de cada página pintada.
  const pageImages = new Map();
  const rememberPages = doc => {
    for (const page of doc.querySelectorAll("[data-page-number]")) {
      if (pageImages.has(page) || page.closest(".thumbnail, #thumbnailView")) continue;
      const canvas = page.querySelector(".canvasWrapper canvas") || page.querySelector("canvas");
      if (!canvas || (page.classList.contains("page") && page.getAttribute("data-loaded") !== "true")) continue;
      const dataUrl = canvasImage(canvas);
      if (dataUrl) pageImages.set(page, { dataUrl, width: canvas.width, height: canvas.height });
    }
  };
  const pendingPage = ".page[data-page-number]:not([data-loaded=\"true\"]) .loadingIcon:not(.notVisible)";
  const deadline = Date.now() + 120_000;
  for (const doc of allDocuments()) {
    const view = doc.defaultView;
    const viewers = Array.from(doc.querySelectorAll("body *")).filter(element =>
      element.querySelector("[data-page-number] canvas, .page[data-page-number]")
      && element.scrollHeight > element.clientHeight + 8
      && /auto|scroll|overlay/.test(view.getComputedStyle(element).overflowY));
    for (const viewer of viewers) {
      const original = viewer.scrollTop;
      for (let y = 0; Date.now() < deadline; y += Math.max(200, viewer.clientHeight * 0.8)) {
        viewer.scrollTop = y;
        await sleep(400);
        for (let wait = 0; wait < 10 && viewer.querySelector(pendingPage); wait++) {
          await sleep(300);
        }
        rememberPages(doc);
        if (viewer.scrollTop + viewer.clientHeight >= viewer.scrollHeight - 2) break;
      }
      viewer.scrollTop = original;
      await sleep(300);
    }
    rememberPages(doc);
  }

  const canvasStyle = (style, dataUrl) => `${style ? `${style.replace(/;?\s*$/, ";")} ` : ""}`
    + `background-image: url(${dataUrl}) !important; background-size: 100% 100% !important; `
    + "background-repeat: no-repeat !important; background-position: center center !important;";
  const frames = [];

  const serialize = doc => {
    const position = frames.length;
    frames.push("");
    const view = doc.defaultView;
    const base = doc.baseURI;
    const live = Array.from(doc.querySelectorAll("*"));
    const copy = doc.documentElement.cloneNode(true);
    const copies = [copy, ...copy.querySelectorAll("*")];
    const removals = [];
    const replacements = [];

    live.forEach((element, livePosition) => {
      const clone = copies[livePosition];
      if (!clone) return;
      const tag = element.localName;

      for (const attribute of Array.from(clone.attributes)) {
        if (/^on/i.test(attribute.name)) clone.removeAttribute(attribute.name);
      }
      if (/url\(/i.test(clone.getAttribute("style") || "")) {
        clone.setAttribute("style", cssUrls(clone.getAttribute("style"), base));
      }

      if (tag === "script" || tag === "noscript" || tag === "base" || (tag === "link" && /preload|prefetch|modulepreload|manifest/i.test(element.rel))) {
        removals.push(clone);
      } else if (tag === "meta" && (element.hasAttribute("charset") || /content-type|content-security-policy|refresh/i.test(element.httpEquiv))) {
        removals.push(clone);
      } else if (tag === "link" && /stylesheet/i.test(element.rel) && element.href) {
        const style = doc.createElement("style");
        if (element.media) style.media = element.media;
        try {
          style.textContent = safeCss(sheetText(element.sheet, element.href));
        } catch {
          style.textContent = `fps-css:${externalCss.length}`;
          externalCss.push(element.href);
        }
        replacements.push([clone, style]);
      } else if (tag === "link" && /icon/i.test(element.rel) && element.href) {
        clone.setAttribute("href", token(element.href, base));
      } else if (tag === "style") {
        try {
          clone.textContent = safeCss(sheetText(element.sheet, base));
        } catch {
          clone.textContent = safeCss(cssUrls(element.textContent, base));
        }
      } else if (tag === "img") {
        const source = element.currentSrc || element.dataset.src || element.dataset.lazySrc || element.src;
        if (source) clone.setAttribute("src", token(source, base));
        clone.removeAttribute("srcset");
        clone.removeAttribute("sizes");
        clone.removeAttribute("loading");
      } else if (tag === "source" && element.parentElement?.localName === "picture") {
        removals.push(clone);
      } else if (tag === "video" && element.poster) {
        clone.setAttribute("poster", token(element.poster, base));
      } else if (tag === "a" && element.getAttribute("href") && !element.getAttribute("href").startsWith("#")) {
        clone.setAttribute("href", element.href);
      } else if (tag === "iframe" || tag === "frame") {
        const inner = frameDocument(element);
        if (inner) {
          // El contenido va dentro del propio archivo: sin esto el iframe
          // vuelve a pedir la URL original, que fuera del sitio se rechaza.
          if (element.src) clone.setAttribute("data-fps-src", element.src);
          clone.removeAttribute("src");
          clone.setAttribute("srcdoc", `fps-frame:${serialize(inner)}`);
        } else if (element.src) {
          clone.setAttribute("src", element.src);
        }
      } else if (tag === "input") {
        if (/checkbox|radio/i.test(element.type)) {
          if (element.checked) clone.setAttribute("checked", "");
          else clone.removeAttribute("checked");
        } else if (element.type !== "password") {
          clone.setAttribute("value", element.value);
        }
      } else if (tag === "textarea") {
        clone.textContent = element.value;
      } else if (tag === "select") {
        const optionCopies = clone.querySelectorAll("option");
        Array.from(element.options).forEach((option, optionIndex) => {
          const optionCopy = optionCopies[optionIndex];
          if (!optionCopy) return;
          if (option.selected) optionCopy.setAttribute("selected", "");
          else optionCopy.removeAttribute("selected");
        });
        if (element.options.length > 1) {
          // Lista visible con todas las opciones del desplegable.
          const list = doc.createElement("ul");
          list.className = "fps-options";
          Array.from(element.options).forEach(option => {
            const item = doc.createElement("li");
            item.textContent = option.text;
            if (option.selected) item.className = "fps-selected";
            list.append(item);
          });
          clone.after(list);
        }
      } else if (tag === "canvas") {
        const page = element.closest("[data-page-number]");
        const dataUrl = canvasImage(element) || pageImages.get(page)?.dataUrl;
        if (dataUrl) {
          clone.setAttribute("width", element.width);
          clone.setAttribute("height", element.height);
          clone.setAttribute("style", canvasStyle(clone.getAttribute("style"), dataUrl));
        }
      }

      // Página del visor que ya no tiene canvas porque se descargó al salir
      // de la vista: se repone con la imagen guardada durante el recorrido.
      if (pageImages.has(element) && !element.querySelector("canvas")) {
        const saved = pageImages.get(element);
        const canvas = doc.createElement("canvas");
        canvas.setAttribute("width", saved.width);
        canvas.setAttribute("height", saved.height);
        canvas.setAttribute("style", canvasStyle("position: absolute; inset: 0; width: 100%; height: 100%; display: block;", saved.dataUrl));
        clone.querySelectorAll(".loadingIcon").forEach(icon => icon.remove());
        clone.append(canvas);
      }

      if (tag !== "html" && element.scrollHeight > element.clientHeight + 8
        && /auto|scroll|hidden/.test(view.getComputedStyle(element).overflowY)) {
        clone.classList.add("fps-grow");
        for (let parent = clone.parentElement; parent && parent !== copy; parent = parent.parentElement) {
          parent.classList.add("fps-grow");
        }
      }
    });
    removals.forEach(element => element.remove());
    replacements.forEach(([from, to]) => from.replaceWith(to));

    const head = copy.querySelector("head") || copy.insertBefore(doc.createElement("head"), copy.firstChild);
    if (doc.adoptedStyleSheets?.length) {
      try {
        const adopted = doc.createElement("style");
        adopted.textContent = safeCss(doc.adoptedStyleSheets.map(sheet => sheetText(sheet, base)).join("\n"));
        head.append(adopted);
      } catch {}
    }
    const charset = doc.createElement("meta");
    charset.setAttribute("charset", "utf-8");
    head.prepend(charset);
    const extra = doc.createElement("style");
    extra.textContent = `
    ul.fps-options{margin:4px 0 8px;padding:6px 10px 6px 26px;border:1px dashed #9aa4b2;border-radius:6px;font-size:12px;background:#f7f8fa;color:#222}
    ul.fps-options .fps-selected{font-weight:700}
    @media print{
      html,body{height:auto!important;overflow:visible!important}
      .fps-grow{height:auto!important;max-height:none!important;overflow:visible!important}
      *{-webkit-print-color-adjust:exact;print-color-adjust:exact}
    }`;
    head.append(extra);

    const doctype = doc.doctype ? `<!DOCTYPE ${doc.doctype.name}>\n` : "";
    frames[position] = `${doctype}${copy.outerHTML}`;
    return position;
  };

  serialize(document);
  const note = `<!-- Guardado con FullPage Saver desde ${location.href.replace(/--/g, "")} el ${new Date().toISOString()} -->\n`;
  frames[0] = frames[0].startsWith("<!DOCTYPE")
    ? frames[0].replace("\n", `\n${note}`)
    : `<!DOCTYPE html>\n${note}${frames[0]}`;
  return {
    frames,
    urls,
    externalCss,
    title: document.title
  };
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

async function runLimited(items, limit, worker) {
  let next = 0;
  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) {
      const current = next++;
      await worker(items[current], current);
    }
  });
  await Promise.all(runners);
}

async function buildHtml(tab) {
  setStatus(t("status.copyingContent"));
  const [result] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: snapshotPageInTab
  });
  const snapshot = result?.result;
  if (!snapshot?.frames?.length) {
    throw new Error(t("err.readContent"));
  }

  const { urls } = snapshot;
  const index = new Map(urls.map((url, position) => [url, position]));
  const token = (value, base) => {
    let absolute;
    try {
      absolute = new URL(value, base).href;
    } catch {
      return value;
    }
    if (!/^https?:/i.test(absolute)) return absolute;
    if (!index.has(absolute)) {
      index.set(absolute, urls.length);
      urls.push(absolute);
    }
    return `fps-res:${index.get(absolute)}`;
  };
  const cssUrls = (text, base) => text.replace(
    /url\(\s*(['"]?)([^'")]+)\1\s*\)/g,
    (match, quote, value) => (/^(data|blob|#)/i.test(value.trim()) ? match : `url("${token(value.trim(), base)}")`)
  );
  const fetchCss = async (url, depth = 0) => {
    try {
      const response = await fetch(url, { credentials: "include" });
      if (!response.ok) return "";
      let text = await response.text();
      if (depth < 2) {
        const imports = [...text.matchAll(/@import\s+(?:url\()?\s*['"]?([^'")\s;]+)['"]?\s*\)?[^;]*;/g)];
        for (const match of imports) {
          text = text.replace(match[0], await fetchCss(new URL(match[1], url).href, depth + 1));
        }
      }
      return cssUrls(text, url);
    } catch {
      return "";
    }
  };

  setStatus(t("status.stylesheets", { n: snapshot.externalCss.length }));
  const cssTexts = await Promise.all(snapshot.externalCss.map(url => fetchCss(url)));

  const dataUrls = new Array(urls.length);
  let done = 0;
  await runLimited(urls, 6, async (url, position) => {
    try {
      const response = await fetch(url, { credentials: "include" });
      if (response.ok) dataUrls[position] = await blobToDataUrl(await response.blob());
    } catch {}
    done++;
    if (done % 5 === 0 || done === urls.length) {
      setStatus(t("status.embedding", { n: done, total: urls.length }));
    }
  });

  setStatus(t("status.generatingHtml"));
  // Cada marco se completa por separado y se mete escapado en el srcdoc de su
  // padre, como hace SavePage WE.
  const escapeAttribute = text => text.replace(/&/g, "&amp;").replace(/"/g, "&quot;");
  const built = new Map();
  const buildFrame = position => {
    if (built.has(position)) return built.get(position);
    const html = snapshot.frames[position]
      // Hoja que no se pudo descargar (por ejemplo, sin el permiso opcional):
      // queda enlazada para que la copia mantenga el estilo con conexión.
      .replace(/fps-css:(\d+)/g, (match, cssPosition) => (cssTexts[cssPosition] || `@import url("${snapshot.externalCss[cssPosition]}");`).replace(/<\/style/gi, "<\\/style"))
      .replace(/fps-res:(\d+)/g, (match, resource) => dataUrls[resource] || urls[resource] || "")
      .replace(/fps-frame:(\d+)/g, (match, child) => escapeAttribute(buildFrame(Number(child))));
    built.set(position, html);
    return html;
  };
  return { html: buildFrame(0), title: snapshot.title || tab.title };
}

// ---------- Permiso opcional para recursos de otros dominios ----------

// El acceso a todos los sitios es opcional: activeTab basta para leer y
// capturar la pestaña. Solo el HTML lo necesita, para descargar las imágenes,
// estilos y fuentes que la página carga desde otros dominios. Chrome exige un
// clic del usuario para pedirlo, así que se pregunta en esta ventana.
const ALL_SITES = { origins: ["<all_urls>"] };

async function askResourcePermission() {
  if (await chrome.permissions.contains(ALL_SITES)) return true;
  const box = document.querySelector("#permission");
  box.hidden = false;
  setStatus(t("perm.missing"));
  const win = await chrome.windows.getCurrent();
  await chrome.windows.update(win.id, { height: 520 }).catch(() => {});
  const granted = await new Promise(resolve => {
    document.querySelector("#grant").addEventListener("click", async () => {
      try {
        resolve(await chrome.permissions.request(ALL_SITES));
      } catch {
        resolve(false);
      }
    }, { once: true });
    document.querySelector("#skip").addEventListener("click", () => resolve(false), { once: true });
  });
  box.hidden = true;
  await chrome.windows.update(win.id, { height: 300 }).catch(() => {});
  return granted;
}

// ---------- Descargas ----------

async function download(blob, filename) {
  const objectUrl = URL.createObjectURL(blob);
  // Esta ventana sigue abierta, así que la URL vive hasta que termine la descarga.
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 10 * 60_000);
  const downloadId = await chrome.downloads.download({ url: objectUrl, filename, saveAs: true });
  if (downloadId === undefined) {
    throw new Error(t("err.download"));
  }
}

async function run() {
  const tab = await getTargetTab();
  document.querySelector("#page-title").textContent = tab.title || tab.url;

  if (MODE === "mht") {
    setStatus(t("status.mht"));
    const archive = await chrome.pageCapture.saveAsMHTML({ tabId: tab.id });
    if (!archive?.size) throw new Error(t("err.mht"));
    await download(new Blob([archive], { type: "multipart/related" }), `${safeFileName(tab.title || "pagina-web")}.mht`);
    return t("done.mht");
  }

  const embedAll = MODE === "html" ? await askResourcePermission() : true;

  await preparePage(tab.id);

  if (MODE === "pdf") {
    const viewer = await captureViewerPages(tab);
    if (viewer) {
      setStatus(t("status.viewerDone", { n: viewer.pages.length }));
      await download(createViewerPdf(viewer.pages), `${safeFileName(viewer.title)}.pdf`);
      return t("done.viewerPdf", { n: viewer.pages.length });
    }
    setStatus(t("status.capturingPage"));
    const captureResult = await captureFullPage(tab);
    setStatus(t("status.captured", { n: captureResult.captures.length }));
    const pdf = await createPdf(captureResult, ORIENTATION);
    await download(pdf, `${safeFileName(captureResult.title)}.pdf`);
    return t("done.pdf", { n: captureResult.captures.length });
  }

  const { html, title } = await buildHtml(tab);
  // Con el tipo text/html Chrome en Windows cambia la extensión a .htm.
  await download(new Blob([html], { type: "application/octet-stream" }), `${safeFileName(title)}.html`);
  if (!embedAll) {
    return t("done.htmlLinked");
  }
  return t("done.html");
}

document.querySelector("#close").addEventListener("click", () => window.close());

run()
  .then(message => {
    setStatus(message);
    document.body.dataset.state = "done";
  })
  .catch(error => {
    const message = error.message || "";
    // Páginas en las que Chrome no deja actuar a ninguna extensión.
    if (/gallery cannot be scripted|cannot be scripted|Cannot access (contents of|a chrome)|ExtensionsSettings policy/i.test(message)) {
      setStatus(t("err.blockedPage"), true);
    } else if (/permission|activeTab/i.test(message)) {
      setStatus(t("err.noAccess"), true);
    } else {
      setStatus(t("err.generic", { msg: message || t("err.unknown") }), true);
    }
    document.body.dataset.state = "error";
  });
