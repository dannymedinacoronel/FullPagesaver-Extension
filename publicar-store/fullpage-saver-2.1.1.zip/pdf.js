const fileInput = document.querySelector("#file-input");
const dropZone = document.querySelector("#drop-zone");
const fileList = document.querySelector("#file-list");
const emptyState = document.querySelector("#empty-state");
const fileCount = document.querySelector("#file-count");
const clearButton = document.querySelector("#clear-files");
const prepareButton = document.querySelector("#prepare");
const scopeSelect = document.querySelector("#scope");
const outputModeSelect = document.querySelector("#output-mode");
const status = document.querySelector("#status");

const selectedFiles = [];
let draggedFileId = null;
let idCounter = 0;

function setStatus(message, isError = false) {
  status.textContent = message;
  status.dataset.error = String(isError);
}

function formatFileSize(size) {
  if (size < 1024 * 1024) {
    return `${Math.max(1, Math.round(size / 1024))} KB`;
  }
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function renderQueue() {
  fileList.replaceChildren();
  selectedFiles.forEach((entry, index) => {
    const item = document.createElement("li");
    item.className = "file-item";
    item.draggable = true;
    item.dataset.fileId = entry.id;

    const handle = document.createElement("span");
    handle.className = "drag-handle";
    handle.textContent = "⠿";
    handle.title = "Arrastra para cambiar el orden";
    handle.setAttribute("aria-hidden", "true");

    const details = document.createElement("div");
    details.className = "file-details";
    const name = document.createElement("div");
    name.className = "file-name";
    name.textContent = entry.file.name;
    name.title = entry.file.name;
    const size = document.createElement("div");
    size.className = "file-size";
    size.textContent = formatFileSize(entry.file.size);
    details.append(name, size);

    const actions = document.createElement("div");
    actions.className = "file-actions";
    const up = document.createElement("button");
    up.className = "file-action";
    up.type = "button";
    up.textContent = "↑";
    up.title = "Mover archivo arriba";
    up.setAttribute("aria-label", `Mover ${entry.file.name} arriba`);
    up.disabled = index === 0;
    up.addEventListener("click", () => moveFile(index, index - 1));
    const down = document.createElement("button");
    down.className = "file-action";
    down.type = "button";
    down.textContent = "↓";
    down.title = "Mover archivo abajo";
    down.setAttribute("aria-label", `Mover ${entry.file.name} abajo`);
    down.disabled = index === selectedFiles.length - 1;
    down.addEventListener("click", () => moveFile(index, index + 1));
    const remove = document.createElement("button");
    remove.className = "file-action remove";
    remove.type = "button";
    remove.textContent = "×";
    remove.title = "Quitar archivo";
    remove.setAttribute("aria-label", `Quitar ${entry.file.name}`);
    remove.addEventListener("click", () => removeFile(entry.id));
    actions.append(up, down, remove);
    item.append(handle, details, actions);
    fileList.append(item);
  });

  const hasFiles = selectedFiles.length > 0;
  fileCount.textContent = String(selectedFiles.length);
  emptyState.hidden = hasFiles;
  clearButton.disabled = !hasFiles;
  prepareButton.disabled = !hasFiles;
  scopeSelect.replaceChildren(new Option("Todos los archivos", "all"));
  selectedFiles.forEach(entry => {
    scopeSelect.add(new Option(entry.file.name, entry.id));
  });
  scopeSelect.disabled = !hasFiles;
  prepareButton.textContent = hasFiles
    ? `Preparar ${selectedFiles.length} archivo(s)`
    : "Preparar vista previa";
}

function addFiles(fileCollection) {
  const candidates = Array.from(fileCollection);
  let added = 0;
  const rejected = [];
  const duplicates = [];

  for (const file of candidates) {
    if (!/\.html?$/i.test(file.name) && file.type !== "text/html") {
      rejected.push(file.name);
      continue;
    }
    if (selectedFiles.some(entry => entry.file.name === file.name
      && entry.file.size === file.size
      && entry.file.lastModified === file.lastModified)) {
      duplicates.push(file.name);
      continue;
    }
    selectedFiles.push({ id: `file-${++idCounter}`, file });
    added++;
  }

  renderQueue();
  const messages = [];
  if (added) messages.push(`Añadido(s): ${added}.`);
  if (duplicates.length) messages.push(`Duplicados omitidos: ${duplicates.join(", ")}.`);
  if (rejected.length) messages.push(`Formato no admitido: ${rejected.join(", ")}.`);
  setStatus(messages.join(" ") || "No se añadieron archivos.");
}

function moveFile(from, to) {
  if (to < 0 || to >= selectedFiles.length) return;
  const [entry] = selectedFiles.splice(from, 1);
  selectedFiles.splice(to, 0, entry);
  renderQueue();
}

function removeFile(id) {
  const index = selectedFiles.findIndex(entry => entry.id === id);
  if (index !== -1) selectedFiles.splice(index, 1);
  renderQueue();
}

fileInput.addEventListener("change", () => {
  addFiles(fileInput.files);
  fileInput.value = "";
});

dropZone.addEventListener("click", event => {
  if (event.target.closest("label")) return;
  fileInput.click();
});

dropZone.addEventListener("keydown", event => {
  if (event.key === "Enter" || event.key === " ") {
    event.preventDefault();
    fileInput.click();
  }
});

for (const type of ["dragenter", "dragover"]) {
  dropZone.addEventListener(type, event => {
    event.preventDefault();
    dropZone.classList.add("is-dragging");
  });
}
for (const type of ["dragleave", "drop"]) {
  dropZone.addEventListener(type, event => {
    event.preventDefault();
    if (type === "drop") addFiles(event.dataTransfer.files);
    dropZone.classList.remove("is-dragging");
  });
}

fileList.addEventListener("dragstart", event => {
  const item = event.target.closest(".file-item");
  if (!item) return;
  draggedFileId = item.dataset.fileId;
  item.classList.add("is-dragging");
  event.dataTransfer.effectAllowed = "move";
  event.dataTransfer.setData("text/plain", draggedFileId);
});

fileList.addEventListener("dragover", event => {
  const target = event.target.closest(".file-item");
  if (!target || !draggedFileId) return;
  event.preventDefault();
  fileList.querySelectorAll(".is-over").forEach(item => item.classList.remove("is-over"));
  target.classList.add("is-over");
});

fileList.addEventListener("drop", event => {
  const target = event.target.closest(".file-item");
  if (!draggedFileId || !target) return;
  event.preventDefault();
  const from = selectedFiles.findIndex(entry => entry.id === draggedFileId);
  const to = selectedFiles.findIndex(entry => entry.id === target.dataset.fileId);
  if (from !== -1 && to !== -1) moveFile(from, to);
  draggedFileId = null;
});

fileList.addEventListener("dragend", () => {
  draggedFileId = null;
  fileList.querySelectorAll(".is-dragging, .is-over").forEach(item => {
    item.classList.remove("is-dragging", "is-over");
  });
});

clearButton.addEventListener("click", () => {
  selectedFiles.splice(0, selectedFiles.length);
  renderQueue();
  setStatus("Se quitaron todos los archivos de la lista.");
});

function findCanvasImage(canvas) {
  const savedImage = canvas.getAttribute("data-savepage-canvasdatauri");
  if (savedImage?.startsWith("data:image/")) return savedImage;
  const background = canvas.getAttribute("style") || "";
  const match = background.match(/url\(["']?(data:image\/[^"')]+)["']?\)/i);
  return match ? match[1] : null;
}

function collectPageImages(html, images, depth = 0) {
  if (depth > 16) {
    throw new Error("El HTML contiene demasiados marcos anidados.");
  }
  const parsed = new DOMParser().parseFromString(html, "text/html");
  for (const element of parsed.querySelectorAll("canvas, iframe[srcdoc]")) {
    if (element.localName === "canvas") {
      const src = findCanvasImage(element);
      if (src) {
        images.push({
          src,
          width: Number(element.getAttribute("width")) || null,
          height: Number(element.getAttribute("height")) || null
        });
      }
    } else {
      collectPageImages(element.getAttribute("srcdoc"), images, depth + 1);
    }
  }
}

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("pagina-completa-pdf", 1);
    request.onupgradeneeded = () => {
      request.result.createObjectStore("jobs", { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("No se pudo abrir el almacenamiento local."));
  });
}

async function saveJob(job) {
  const database = await openDatabase();
  try {
    await new Promise((resolve, reject) => {
      const transaction = database.transaction("jobs", "readwrite");
      const store = transaction.objectStore("jobs");
      const existingJobs = store.getAll();
      existingJobs.onsuccess = () => {
        const cutoff = Date.now() - 24 * 60 * 60 * 1000;
        for (const existing of existingJobs.result) {
          if (existing.createdAt < cutoff) store.delete(existing.id);
        }
        store.put(job);
      };
      existingJobs.onerror = () => {
        transaction.abort();
        reject(existingJobs.error || new Error("No se pudieron limpiar las vistas antiguas."));
      };
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error || new Error("No se pudo guardar la vista previa."));
      transaction.onabort = () => reject(transaction.error || new Error("Se canceló el guardado de la vista previa."));
    });
  } finally {
    database.close();
  }
}

function orderFiles() {
  const files = [...selectedFiles];
  if (document.querySelector("#order").value === "name") {
    files.sort((a, b) => a.file.name.localeCompare(b.file.name, "es", { sensitivity: "base" }));
  }
  return files;
}

document.querySelector("#order").addEventListener("change", () => {
  if (document.querySelector("#order").value === "name") {
    selectedFiles.sort((a, b) =>
      a.file.name.localeCompare(b.file.name, "es", { sensitivity: "base" })
    );
    renderQueue();
  }
});

prepareButton.addEventListener("click", async () => {
  if (selectedFiles.length === 0) {
    setStatus("Añade al menos un archivo HTML antes de continuar.", true);
    return;
  }
  prepareButton.disabled = true;
  setStatus(`Leyendo ${selectedFiles.length} archivo(s)…`);
  const files = orderFiles();
  const preparedFiles = [];
  const failures = [];
  try {
    for (const entry of files) {
      try {
        const images = [];
        collectPageImages(await entry.file.text(), images);
        if (images.length === 0) {
          failures.push(`${entry.file.name}: no contiene páginas de canvas guardadas.`);
        } else {
          preparedFiles.push({ id: entry.id, name: entry.file.name, images });
        }
      } catch (error) {
        failures.push(`${entry.file.name}: ${error.message}`);
      }
    }

    if (preparedFiles.length === 0) {
      setStatus(failures.join(" ") || "No se encontraron páginas exportables.", true);
      return;
    }

    const scope = scopeSelect.value;
    const filesToExport = scope === "all"
      ? preparedFiles
      : preparedFiles.filter(file => file.id === scope);
    if (filesToExport.length === 0) {
      setStatus("El archivo elegido no contiene páginas exportables.", true);
      return;
    }
    const options = {
      paper: document.querySelector("#paper").value,
      orientation: document.querySelector("#orientation").value,
      margin: Number(document.querySelector("#margin").value),
      fit: document.querySelector("#fit").value
    };
    const independent = outputModeSelect.value === "separate";
    const outputFiles = filesToExport.map(file => ({
      name: file.name,
      pages: file.images.map(image => ({ ...image, source: file.name }))
    }));
    const pages = outputFiles.flatMap(file => file.pages);
    const job = {
      id: `job-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      createdAt: Date.now(),
      title: independent
        ? `${outputFiles.length} PDF independiente(s)`
        : filesToExport.map(file => file.name).join(", "),
      options,
      ...(independent
        ? { files: outputFiles }
        : { pages })
    };
    await saveJob(job);
    await chrome.tabs.create({ url: chrome.runtime.getURL(`preview.html?job=${encodeURIComponent(job.id)}`) });
    setStatus(
      independent
        ? `Preparados ${outputFiles.length} PDF independiente(s). En la pestaña nueva elige un archivo y guarda cada PDF por separado.${failures.length ? ` Archivos omitidos: ${failures.join(" ")}` : ""}`
        : `Preparadas ${filesToExport.length} archivo(s) y ${pages.length} página(s) para un PDF combinado.${failures.length ? ` Archivos omitidos: ${failures.join(" ")}` : ""}`
    );
  } catch (error) {
    setStatus(`No se pudo preparar la vista previa: ${error.message}`, true);
  } finally {
    prepareButton.disabled = selectedFiles.length === 0;
  }
});

renderQueue();
