# FullPage Saver

Extensión de Chrome Manifest V3 para:

- Guardar la pestaña web activa como archivo `.mhtml` usando la captura integrada de Chrome. El archivo reúne la página y los recursos que Chrome tenga cargados; se guarda localmente y se puede abrir en Chrome.
- Recorrer la pestaña activa, capturar su contenido visible en pantallas consecutivas y generar directamente un archivo PDF descargable.
- Exportar las páginas visibles de elementos `canvas` como un HTML autocontenido compatible con el conversor PDF de esta extensión.
- Importar uno o varios HTML guardados con imágenes de páginas serializadas en `canvas`, reordenarlos con arrastrar y soltar o con los botones de flecha, y preparar una vista de impresión para guardarlos como PDF.

## Instalar en Chrome

1. Abre `chrome://extensions`.
2. Activa **Modo de desarrollador**.
3. Pulsa **Cargar descomprimida** y selecciona esta carpeta `extension-chrome`. Chrome mostrará los permisos que necesita la extensión para capturar la pestaña y descargar la copia. Si ya la habías instalado, pulsa el botón de recarga para instalar la versión 2.1.1.
4. Fija **FullPage Saver** en la barra de extensiones.
5. Abre la página, pulsa el icono de la extensión y elige **Guardar la página completa como PDF**. La extensión captura las pantallas mientras recorre la página, compone un PDF y abre el diálogo de Chrome para elegir dónde guardar el archivo. Puedes elegir papel y orientación antes de iniciar.
6. Para guardar una copia de archivo web en vez de PDF, selecciona **Archivar página web (.mht)**.

Para los PDF, abre la extensión, elige **Crear PDF desde HTML guardados**, añade archivos con el selector o arrástralos a la zona de carga y configura las opciones. En **Archivos de salida**, puedes elegir un único PDF combinado o **PDF independiente por cada archivo**. Pulsa **Preparar vista previa**. En el modo independiente, la nueva pestaña muestra un selector de archivo; elige el que quieras y pulsa **Guardar este PDF**. Chrome preguntará dónde guardarlo. Repite con cada archivo que quieras exportar; puedes dejar sin guardar los demás.

## Notas

- El archivo MHTML lo genera Chrome con `chrome.pageCapture.saveAsMHTML`; representa la pestaña y los recursos capturados por Chrome, no todos los resultados posibles de controles interactivos. Una lista desplegable que hace nuevas llamadas solo muestra los datos de la opción abierta y cargada en el momento de guardar. Para conservar varias opciones, guárdalas desde la función de exportación original de la aplicación o desde su fuente/servidor autorizado.
- El PDF directo se compone en el navegador. Si el área desplazable es un visor de páginas (PDF.js y similares, también dentro de iframes del mismo origen), cada página se copia de su propio canvas a su tamaño original: sin uniones ni barras repetidas. En el resto de páginas se une una serie de capturas consecutivas del área visible; los elementos fijos (cabeceras, botones flotantes) solo aparecen en la primera captura. Mantén Chrome en primer plano y no cambies de pestaña mientras captura. El diseño queda como imagen, no como texto seleccionable. Por seguridad y memoria, el límite es de 120 pantallas.
- El HTML se guarda como SavePage WE: un único archivo .html sin scripts, con estilos, imágenes y fuentes incrustados, el contenido de los iframes del mismo origen dentro de `srcdoc` y cada `canvas` guardado como imagen. En visores tipo PDF.js se recorren todas las páginas para guardarlas aunque el visor ya las haya descargado. Es compatible con el conversor PDF de esta extensión. Los iframes de otros dominios se mantienen con su dirección original.
- Para la conversión a PDF, cada imagen guardada en el HTML se ajusta a una hoja. Los controles del diálogo de impresión (por ejemplo, destino y escala) siguen perteneciendo a Chrome.
- Permisos: para leer, recorrer y capturar la pestaña basta `activeTab` (se concede al abrir la extensión). El acceso a todos los sitios es opcional: solo se pide, con un botón, al guardar en HTML, para incrustar imágenes, estilos y fuentes de otros dominios. Sin él, esos recursos quedan enlazados en la copia.
- La extensión no envía archivos ni páginas a un servidor. Los datos de la vista previa se guardan en IndexedDB local de la extensión; usa **Eliminar datos temporales** al terminar si quieres borrarlos.

## Aviso legal

FullPage Saver es una extensión gratuita de **Danny Medina Coronel** (empresademkor@gmail.com), que actúa como particular. Se ofrece «tal cual», sin garantías. El usuario es el único responsable del uso que haga de la extensión y de las copias que genere: debe guardar solo contenido sobre el que tenga derechos o permiso, respetar la propiedad intelectual y los términos de cada sitio, y no eludir medidas de protección ni restricciones de acceso. En la máxima medida permitida por la ley, el titular no se hace responsable de usos indebidos ni de los daños derivados del uso de la extensión. El texto completo, con la política de privacidad, está en `legal.html` (enlazado desde el popup).
