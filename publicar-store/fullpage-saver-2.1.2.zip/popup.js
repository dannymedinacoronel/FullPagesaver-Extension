const status = document.querySelector("#status");

// Chrome no deja que ninguna extensión ejecute código en su tienda.
const BLOCKED_HOSTS = /^(chromewebstore\.google\.com|chrome\.google\.com)$/i;

async function startJob(mode) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !/^https?:\/\//i.test(tab.url || "")) {
      throw new Error("Abre una página web (http o https) antes de guardar.");
    }
    const { hostname, pathname } = new URL(tab.url);
    if (BLOCKED_HOSTS.test(hostname) && (hostname !== "chrome.google.com" || pathname.startsWith("/webstore"))) {
      throw new Error("Chrome no permite usar extensiones en la Chrome Web Store. Abre la página que quieras guardar y vuelve a pulsar el botón.");
    }
    const params = new URLSearchParams({
      tab: String(tab.id),
      mode,
      paper: document.querySelector("#paper").value,
      orientation: document.querySelector("#orientation").value
    });
    // El trabajo corre en una ventana propia: el popup se cierra al perder el
    // foco y antes cortaba la captura y la descarga.
    await chrome.windows.create({
      url: chrome.runtime.getURL(`save.html?${params}`),
      type: "popup",
      width: 440,
      height: 300,
      focused: true
    });
    window.close();
  } catch (error) {
    status.textContent = error.message;
    status.dataset.error = "true";
  }
}

document.querySelector("#save-html").addEventListener("click", () => startJob("html"));
document.querySelector("#save-pdf").addEventListener("click", () => startJob("pdf"));
document.querySelector("#save-page").addEventListener("click", () => startJob("mht"));
document.querySelector("#open-pdf").addEventListener("click", async () => {
  await chrome.tabs.create({ url: chrome.runtime.getURL("pdf.html") });
  window.close();
});
