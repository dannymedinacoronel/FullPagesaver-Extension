# FullPage Saver

Extensión de Chrome Manifest V3 para:

- Guardar la pestaña web activa como archivo `.mhtml` usando la captura integrada de Chrome. El archivo reúne la página y los recursos que Chrome tenga cargados; se guarda localmente y se puede abrir en Chrome.
- Recorrer la pestaña activa, capturar su contenido visible en pantallas consecutivas y generar directamente un archivo PDF descargable.
- Exportar las páginas visibles de elementos `canvas` como un HTML autocontenido compatible con el conversor PDF de esta extensión.
- Importar uno o varios HTML guardados con imágenes de páginas serializadas en `canvas`, reordenarlos con arrastrar y soltar o con los botones de flecha, y preparar una vista de impresión para guardarlos como PDF.

## Instalar en Chrome

1. Abre `chrome://extensions`.
2. Activa **Modo de desarrollador**.
3. Pulsa **Cargar descomprimida** y selecciona esta carpeta `extension-chrome`. Chrome mostrará los permisos que necesita la extensión para capturar la pestaña y descargar la copia. Si ya la habías instalado, pulsa el botón de recarga para instalar la versión 2.0.0.
4. Fija **FullPage Saver** en la barra de extensiones.
5. Abre la página, pulsa el icono de la extensión y elige **Guardar la página completa como PDF**. La extensión captura las pantallas mientras recorre la página, compone un PDF y abre el diálogo de Chrome para elegir dónde guardar el archivo. Puedes elegir papel y orientación antes de iniciar.
6. Para guardar una copia de archivo web en vez de PDF, selecciona **Archivar página web (.mht)**.

Para los PDF, abre la extensión, elige **Crear PDF desde HTML guardados**, añade archivos con el selector o arrástralos a la zona de carga y configura las opciones. En **Archivos de salida**, puedes elegir un único PDF combinado o **PDF independiente por cada archivo**. Pulsa **Preparar vista previa**. En el modo independiente, la nueva pestaña muestra un selector de archivo; elige el que quieras y pulsa **Guardar este PDF**. Chrome preguntará dónde guardarlo. Repite con cada archivo que quieras exportar; puedes dejar sin guardar los demás.

## Notas

- El archivo MHTML lo genera Chrome con `chrome.pageCapture.saveAsMHTML`; representa la pestaña y los recursos capturados por Chrome, no todos los resultados posibles de controles interactivos. Una lista desplegable que hace nuevas llamadas solo muestra los datos de la opción abierta y cargada en el momento de guardar. Para conservar varias opciones, guárdalas desde la función de exportación original de la aplicación o desde su fuente/servidor autorizado; la extensión no recorre ni extrae resultados ocultos de visores.
- El PDF directo se compone en el navegador a partir de capturas consecutivas del área desplazable visible. El capturador mantiene el mismo panel durante el recorrido, espera contenido de carga progresiva y confirma que el final permanece estable antes de parar. Mantén Chrome en primer plano y no cambies de pestaña mientras captura. El diseño queda como imagen, no como texto seleccionable; encabezados fijos pueden aparecer en más de una captura. Por seguridad y memoria, el límite es de 120 pantallas.
- El HTML compatible con el conversor contiene imágenes autocontenidas de las páginas legibles en `canvas`; no es una copia completa del DOM. Si no se detectan páginas o el sitio bloquea la lectura del canvas, usa la opción MHT para archivar lo que Chrome permita.
- Para la conversión a PDF, cada imagen guardada en el HTML se ajusta a una hoja. Los controles del diálogo de impresión (por ejemplo, destino y escala) siguen perteneciendo a Chrome.
- La extensión no envía archivos ni páginas a un servidor. Los datos de la vista previa se guardan en IndexedDB local de la extensión; usa **Eliminar datos temporales** al terminar si quieres borrarlos.
