const params = new URLSearchParams(location.search);
const TARGET_TAB_ID = Number(params.get("tab"));
const MODE = params.get("mode") || "html";
const PAPER = params.get("paper") || "A4";
const ORIENTATION = params.get("orientation") || "portrait";
const status = document.querySelector("#status");
const MAX_CAPTURES = 120;
const SCROLL_STEP = 0.8;
const SCROLL_SETTLE_MS = 900;
const END_STABILITY_PASSES = 3;

const PAPER_SIZES = {
  A4: [210, 297],
  Letter: [215.9, 279.4],
  A3: [297, 420],
  Legal: [215.9, 355.6]
};

function setStatus(message, isError = false) {
  status.textContent = message;
  status.dataset.error = String(isError);
}

function safeFileName(value) {
  const cleaned = value
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, "_")
    .replace(/[. ]+$/g, "")
    .trim()
    .slice(0, 150);
  return cleaned || "pagina-web";
}

async function getTargetTab() {
  const tab = await chrome.tabs.get(TARGET_TAB_ID);
  if (!tab?.id) {
    throw new Error("No se encontró la pestaña que querías guardar.");
  }
  if (!/^https?:\/\//i.test(tab.url || "")) {
    throw new Error("Chrome solo permite capturar páginas HTTP o HTTPS.");
  }
  return tab;
}

async function readPageMetrics(tabId) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const root = document.scrollingElement || document.documentElement;
      const candidates = Array.from(document.querySelectorAll("body *"))
        .filter(element => {
          const style = getComputedStyle(element);
          const scrollable = /auto|scroll|overlay/.test(style.overflowY);
          const rect = element.getBoundingClientRect();
          const tagName = element.localName;
          return scrollable
            && !["select", "textarea", "option", "iframe"].includes(tagName)
            && element.clientHeight > 100
            && element.scrollHeight > element.clientHeight + 8
            && rect.width > 100
            && rect.height > 100
            && rect.right > 0
            && rect.bottom > 0
            && rect.left < window.innerWidth
            && rect.top < window.innerHeight
            && element.clientWidth / Math.max(1, element.clientHeight) > 0.45;
        })
        .sort((first, second) =>
          (second.clientWidth * second.clientHeight)
          - (first.clientWidth * first.clientHeight)
        );
      const target = candidates[0] || root;
      let selector = "";

      if (target !== root) {
        const parts = [];
        let current = target;
        while (current && current !== document.documentElement) {
          if (current.id) {
            parts.unshift(`#${CSS.escape(current.id)}`);
            break;
          }
          const sameTag = Array.from(current.parentElement?.children || [])
            .filter(sibling => sibling.localName === current.localName);
          const position = sameTag.indexOf(current) + 1;
          parts.unshift(`${current.localName}:nth-of-type(${position})`);
          current = current.parentElement;
        }
        selector = parts.join(" > ");
      }

      const rect = target === root
        ? { left: 0, top: 0, right: window.innerWidth, bottom: window.innerHeight }
        : target.getBoundingClientRect();
      let left = Math.max(0, rect.left);
      let top = Math.max(0, rect.top);
      let right = Math.min(window.innerWidth, rect.right);
      let bottom = Math.min(window.innerHeight, rect.bottom);

      for (let ancestor = target.parentElement; ancestor && right > left && bottom > top; ancestor = ancestor.parentElement) {
        const style = getComputedStyle(ancestor);
        const ancestorRect = ancestor.getBoundingClientRect();
        if (/(hidden|clip|auto|scroll)/.test(`${style.overflowX} ${style.overflowY}`)) {
          left = Math.max(left, ancestorRect.left);
          top = Math.max(top, ancestorRect.top);
          right = Math.min(right, ancestorRect.right);
          bottom = Math.min(bottom, ancestorRect.bottom);
        }
      }

      return {
        title: document.title,
        selector,
        isDocument: target === root,
        layoutViewportWidth: window.innerWidth,
        viewportWidth: Math.max(0, right - left),
        viewportHeight: Math.max(0, bottom - top),
        cropLeft: left,
        cropTop: top,
        clientHeight: target.clientHeight,
        documentHeight: target.scrollHeight,
        scrollY: target === root ? window.scrollY : target.scrollTop
      };
    }
  });
  if (!result?.result?.viewportWidth || !result.result.viewportHeight || !result.result.documentHeight) {
    throw new Error(
      "No se encontró un área de página visible y desplazable en la pestaña activa."
    );
  }
  return result.result;
}

async function scrollPage(tabId, metrics, y) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (selector, isDocument, requestedY) => {
      if (isDocument) {
        const root = document.scrollingElement || document.documentElement;
        const documentElement = document.documentElement;
        const body = document.body;
        const originalRootBehavior = root.style.scrollBehavior;
        const originalHtmlBehavior = documentElement.style.scrollBehavior;
        const originalBodyBehavior = body?.style.scrollBehavior;
        root.style.scrollBehavior = "auto";
        documentElement.style.scrollBehavior = "auto";
        if (body) body.style.scrollBehavior = "auto";
        window.scrollTo(0, requestedY);
        const actualY = window.scrollY;
        root.style.scrollBehavior = originalRootBehavior;
        documentElement.style.scrollBehavior = originalHtmlBehavior;
        if (body) body.style.scrollBehavior = originalBodyBehavior;
        return actualY;
      }
      const element = document.querySelector(selector);
      if (!element) return null;
      const originalBehavior = element.style.scrollBehavior;
      element.style.scrollBehavior = "auto";
      element.scrollTop = requestedY;
      const actualY = element.scrollTop;
      element.style.scrollBehavior = originalBehavior;
      return actualY;
    },
    args: [metrics.selector, metrics.isDocument, y]
  });
  if (typeof result?.result !== "number") {
    throw new Error("No se pudo desplazar el área de contenido de la página.");
  }
  return result.result;
}

function delay(milliseconds) {
  return new Promise(resolve => window.setTimeout(resolve, milliseconds));
}

async function captureFullPage(tab) {
  const initialMetrics = await readPageMetrics(tab.id);
  let metrics = initialMetrics;
  let documentHeight = initialMetrics.documentHeight;
  let lastPosition = -1;
  let nextPosition = 0;
  let stableAtEndPasses = 0;
  let stalledPasses = 0;
  const captures = [];

  try {
    while (true) {
      if (captures.length >= MAX_CAPTURES) {
        throw new Error(
          `La página supera el límite de captura de ${MAX_CAPTURES} pantallas.`
        );
      }

      const maximumScroll = Math.max(
        0,
        documentHeight - (metrics.isDocument ? metrics.viewportHeight : metrics.clientHeight)
      );
      const requestedPosition = Math.min(nextPosition, maximumScroll);
      const scrollY = await scrollPage(tab.id, metrics, requestedPosition);
      setStatus(`Capturando pantalla ${captures.length + 1}…`);
      await delay(SCROLL_SETTLE_MS);

      const screenshotUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
        format: "png"
      });
      if (!screenshotUrl?.startsWith("data:image/")) {
        throw new Error("Chrome no devolvió la captura de pantalla.");
      }

      const dataUrl = await cropCapture(
        screenshotUrl,
        metrics,
        metrics.layoutViewportWidth
      );
      captures.push({ dataUrl, scrollY });

      const updatedMetrics = await readPageMetrics(tab.id);
      if (
        updatedMetrics.selector !== initialMetrics.selector
        || updatedMetrics.isDocument !== initialMetrics.isDocument
      ) {
        throw new Error(
          "El área desplazable cambió durante la captura. Espera a que la página termine de cargar e inténtalo de nuevo."
        );
      }

      const previousHeight = documentHeight;
      documentHeight = Math.max(documentHeight, updatedMetrics.documentHeight);
      metrics = updatedMetrics;
      const scrollableHeight = metrics.isDocument
        ? metrics.viewportHeight
        : metrics.clientHeight;
      const currentMaximum = Math.max(0, documentHeight - scrollableHeight);
      const isAtEnd = scrollY >= currentMaximum - 2;
      if (scrollY === lastPosition && !isAtEnd) {
        stalledPasses++;
      } else {
        stalledPasses = 0;
      }
      if (stalledPasses >= 3) {
        throw new Error(
          "La página dejó de desplazarse antes de llegar al final. Comprueba que el visor permita recorrer el contenido visible."
        );
      }
      lastPosition = scrollY;

      if (isAtEnd && documentHeight === previousHeight) {
        stableAtEndPasses++;
      } else {
        stableAtEndPasses = 0;
      }

      if (stableAtEndPasses >= END_STABILITY_PASSES) break;

      if (isAtEnd) {
        await delay(SCROLL_SETTLE_MS);
        const settledMetrics = await readPageMetrics(tab.id);
        if (
          settledMetrics.selector !== initialMetrics.selector
          || settledMetrics.isDocument !== initialMetrics.isDocument
        ) {
          throw new Error(
            "El área desplazable cambió mientras se cargaba contenido. Vuelve a iniciar la captura cuando la página esté estable."
          );
        }
        metrics = settledMetrics;
        documentHeight = Math.max(documentHeight, settledMetrics.documentHeight);
        nextPosition = Math.min(
          documentHeight,
          scrollY + metrics.viewportHeight * SCROLL_STEP
        );
      } else {
        nextPosition = scrollY + metrics.viewportHeight * SCROLL_STEP;
      }
    }
  } finally {
    await scrollPage(tab.id, initialMetrics, initialMetrics.scrollY);
  }

  return {
    captures,
    title: initialMetrics.title,
    viewportWidth: initialMetrics.viewportWidth,
    documentHeight,
    layoutViewportWidth: initialMetrics.layoutViewportWidth
  };
}

async function cropCapture(screenshotUrl, metrics, layoutViewportWidth) {
  const image = await loadCapture(screenshotUrl);
  const scale = image.naturalWidth / layoutViewportWidth;
  const left = Math.max(0, Math.round(metrics.cropLeft * scale));
  const top = Math.max(0, Math.round(metrics.cropTop * scale));
  const width = Math.min(
    image.naturalWidth - left,
    Math.round(metrics.viewportWidth * scale)
  );
  const height = Math.min(
    image.naturalHeight - top,
    Math.round(metrics.viewportHeight * scale)
  );
  if (!width || !height) {
    throw new Error("El área desplazable no está visible en la captura.");
  }
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d", { alpha: false });
  if (!context) {
    throw new Error("No se pudo recortar la captura de la página.");
  }
  context.drawImage(image, left, top, width, height, 0, 0, width, height);
  return canvas.toDataURL("image/jpeg", 0.88);
}

async function loadCapture(dataUrl) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("No se pudo leer una de las capturas."));
    image.src = dataUrl;
  });
}

function canvasToJpegBytes(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(async blob => {
      if (!blob) {
        reject(new Error("No se pudo comprimir una página del PDF."));
        return;
      }
      try {
        resolve(new Uint8Array(await blob.arrayBuffer()));
      } catch (error) {
        reject(error);
      }
    }, "image/jpeg", 0.86);
  });
}

async function makePdfPage(captures, pageIndex, pageHeight, documentHeight) {
  const width = captures[0].image.naturalWidth;
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = pageHeight;
  const context = canvas.getContext("2d", { alpha: false });
  if (!context) {
    throw new Error("El navegador no pudo preparar una página del PDF.");
  }
  context.fillStyle = "#fff";
  context.fillRect(0, 0, canvas.width, canvas.height);

  const pageStart = pageIndex * pageHeight;
  const pageEnd = Math.min(pageStart + pageHeight, documentHeight);
  for (const capture of captures) {
    const captureStart = Math.round(capture.scrollY * capture.scale);
    const captureEnd = captureStart + capture.image.naturalHeight;
    const overlapStart = Math.max(pageStart, captureStart);
    const overlapEnd = Math.min(pageEnd, captureEnd);
    if (overlapEnd <= overlapStart) continue;

    const sourceY = overlapStart - captureStart;
    const destinationY = overlapStart - pageStart;
    const segmentHeight = overlapEnd - overlapStart;
    context.drawImage(
      capture.image,
      0,
      sourceY,
      width,
      segmentHeight,
      0,
      destinationY,
      width,
      segmentHeight
    );
  }

  return canvasToJpegBytes(canvas);
}

function encodeText(value) {
  return new TextEncoder().encode(value);
}

function createPdfBlob(jpegPages, pageWidthMm, pageHeightMm) {
  const pageWidthPt = pageWidthMm * 72 / 25.4;
  const pageHeightPt = pageHeightMm * 72 / 25.4;
  const pageCount = jpegPages.length;
  const objectCount = 2 + pageCount * 3;
  const objects = new Array(objectCount + 1);

  objects[1] = { parts: [encodeText("<< /Type /Catalog /Pages 2 0 R >>")] };
  objects[2] = {
    parts: [
      encodeText(
        `<< /Type /Pages /Kids [${jpegPages.map((_, index) => `${3 + index * 3} 0 R`).join(" ")}] /Count ${pageCount} >>`
      )
    ]
  };

  jpegPages.forEach((jpeg, index) => {
    const pageObjectId = 3 + index * 3;
    const imageObjectId = pageObjectId + 1;
    const contentObjectId = pageObjectId + 2;
    objects[pageObjectId] = {
      parts: [
        encodeText(
          `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidthPt.toFixed(3)} ${pageHeightPt.toFixed(3)}] /Resources << /XObject << /Im0 ${imageObjectId} 0 R >> >> /Contents ${contentObjectId} 0 R >>`
        )
      ]
    };
    objects[imageObjectId] = {
      parts: [
        encodeText(
          `<< /Type /XObject /Subtype /Image /Width ${jpeg.width} /Height ${jpeg.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.bytes.length} >>\nstream\n`
        ),
        jpeg.bytes,
        encodeText("\nendstream")
      ]
    };
    const imageHeightPt = pageWidthPt * jpeg.height / jpeg.width;
    const content = encodeText(
      `q\n${pageWidthPt.toFixed(3)} 0 0 ${imageHeightPt.toFixed(3)} 0 ${(pageHeightPt - imageHeightPt).toFixed(3)} cm\n/Im0 Do\nQ`
    );
    objects[contentObjectId] = {
      parts: [
        encodeText(`<< /Length ${content.length} >>\nstream\n`),
        content,
        encodeText("\nendstream")
      ]
    };
  });

  const chunks = [encodeText("%PDF-1.4\n")];
  const offsets = new Array(objectCount + 1).fill(0);
  let byteOffset = chunks[0].length;
  for (let id = 1; id <= objectCount; id++) {
    offsets[id] = byteOffset;
    const objectParts = [
      encodeText(`${id} 0 obj\n`),
      ...objects[id].parts,
      encodeText("\nendobj\n")
    ];
    chunks.push(...objectParts);
    byteOffset += objectParts.reduce((total, part) => total + part.length, 0);
  }

  const xrefOffset = byteOffset;
  let xref = `xref\n0 ${objectCount + 1}\n0000000000 65535 f \n`;
  for (let id = 1; id <= objectCount; id++) {
    xref += `${String(offsets[id]).padStart(10, "0")} 00000 n \n`;
  }
  xref += `trailer\n<< /Size ${objectCount + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;
  chunks.push(encodeText(xref));
  return new Blob(chunks, { type: "application/pdf" });
}

async function createPdf(captureResult, orientation) {
  if (!captureResult.captures.length) {
    throw new Error("No se pudo capturar ninguna pantalla de la página.");
  }

  setStatus("Preparando las capturas para el PDF…");
  const captures = [];
  for (const capture of captureResult.captures) {
    const image = await loadCapture(capture.dataUrl);
    captures.push({
      ...capture,
      image,
      scale: image.naturalWidth / captureResult.viewportWidth
    });
  }

  const paper = PAPER;
  const [shortSide, longSide] = PAPER_SIZES[paper] || PAPER_SIZES.A4;
  const pageWidthMm = orientation === "landscape" ? longSide : shortSide;
  const pageHeightMm = orientation === "landscape" ? shortSide : longSide;
  const pixelsPerCssPixel = captures[0].scale;
  const pageHeightPx = Math.ceil(
    captures[0].image.naturalWidth * pageHeightMm / pageWidthMm
  );
  const documentHeightPx = Math.ceil(
    captureResult.documentHeight * pixelsPerCssPixel
  );
  const pageCount = Math.max(1, Math.ceil(documentHeightPx / pageHeightPx));
  const jpegPages = [];

  for (let index = 0; index < pageCount; index++) {
    setStatus(`Componiendo PDF: página ${index + 1} de ${pageCount}…`);
    const pageRasterHeight = Math.min(
      pageHeightPx,
      documentHeightPx - index * pageHeightPx
    );
    jpegPages.push({
      width: captures[0].image.naturalWidth,
      height: pageRasterHeight,
      bytes: await makePdfPage(captures, index, pageRasterHeight, documentHeightPx)
    });
  }

  return createPdfBlob(jpegPages, pageWidthMm, pageHeightMm);
}

// ---------- Preparación: abrir menús y recorrer hasta el final ----------

// Se inyecta en la página. Abre desplegables/acordeones y baja hasta el final
// para forzar la carga diferida; después vuelve arriba.
async function preparePageInTab() {
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const clicked = new WeakSet();

  const expand = () => {
    let opened = 0;
    document.querySelectorAll("details:not([open])").forEach(element => {
      element.open = true;
      opened++;
    });
    document.querySelectorAll(".collapse:not(.show)").forEach(element => {
      element.classList.add("show");
      opened++;
    });
    document.querySelectorAll('[aria-expanded="false"]').forEach(element => {
      if (clicked.has(element)) return;
      if (element.matches("select, input, textarea, [role=combobox]")) return;
      const link = element.closest("a[href]");
      if (link && !/^(#|javascript:)/i.test(link.getAttribute("href") || "")) return;
      if (element.closest("form") && element.matches("button[type=submit], button:not([type])") && !element.hasAttribute("aria-controls")) return;
      clicked.add(element);
      try {
        element.click();
        opened++;
      } catch {}
    });
    return opened;
  };

  const scrollTargets = () => {
    const root = document.scrollingElement || document.documentElement;
    const inner = Array.from(document.querySelectorAll("body *")).filter(element => {
      const style = getComputedStyle(element);
      return /auto|scroll|overlay/.test(style.overflowY)
        && element.scrollHeight > element.clientHeight + 8
        && element.clientHeight > 100;
    });
    return [root, ...inner];
  };

  const scrollToEnd = async (element, deadline) => {
    let stable = 0;
    let lastHeight = -1;
    while (stable < 3 && Date.now() < deadline) {
      const step = Math.max(200, (element.clientHeight || innerHeight) * 0.8);
      element.scrollTop = Math.min(element.scrollTop + step, element.scrollHeight);
      await sleep(350);
      const atEnd = element.scrollTop + element.clientHeight >= element.scrollHeight - 2;
      if (atEnd && element.scrollHeight === lastHeight) stable++;
      else stable = atEnd ? 1 : 0;
      lastHeight = element.scrollHeight;
    }
    element.scrollTop = 0;
  };

  const deadline = Date.now() + 90_000;
  for (let round = 0; round < 4; round++) {
    const opened = expand();
    await sleep(500);
    for (const element of scrollTargets()) {
      await scrollToEnd(element, deadline);
    }
    if (!opened && round > 0) break;
  }
  window.scrollTo(0, 0);
  await sleep(400);
  return true;
}

async function preparePage(tabId) {
  setStatus("Abriendo menús y recorriendo la página hasta el final…");
  await chrome.scripting.executeScript({ target: { tabId }, func: preparePageInTab });
}

// ---------- Copia HTML autocontenida ----------

// Se inyecta en la página. Devuelve el HTML con los recursos marcados como
// "fps-res:N" y las hojas externas que no se pudieron leer como "fps-css:N".
function snapshotPageInTab() {
  const urls = [];
  const index = new Map();
  const externalCss = [];
  const token = (value, base = document.baseURI) => {
    let absolute;
    try {
      absolute = new URL(value, base).href;
    } catch {
      return value;
    }
    if (!/^https?:/i.test(absolute)) return absolute;
    if (!index.has(absolute)) {
      index.set(absolute, urls.length);
      urls.push(absolute);
    }
    return `fps-res:${index.get(absolute)}`;
  };
  const cssUrls = (text, base) => text.replace(
    /url\(\s*(['"]?)([^'")]+)\1\s*\)/g,
    (match, quote, value) => (/^(data|blob|#)/i.test(value.trim()) ? match : `url("${token(value.trim(), base)}")`)
  );
  const sheetText = (sheet, base) => Array.from(sheet.cssRules).map(rule => {
    if (rule instanceof CSSImportRule && rule.styleSheet) {
      try {
        return sheetText(rule.styleSheet, rule.styleSheet.href || base);
      } catch {
        return rule.cssText;
      }
    }
    return cssUrls(rule.cssText, base);
  }).join("\n");
  const safeCss = text => text.replace(/<\/style/gi, "<\\/style");

  const live = Array.from(document.querySelectorAll("*"));
  const copy = document.documentElement.cloneNode(true);
  const copies = [copy, ...copy.querySelectorAll("*")];
  const removals = [];
  const replacements = [];

  live.forEach((element, position) => {
    const clone = copies[position];
    if (!clone) return;
    const tag = element.localName;

    for (const attribute of Array.from(clone.attributes)) {
      if (/^on/i.test(attribute.name)) clone.removeAttribute(attribute.name);
    }
    if (/url\(/i.test(clone.getAttribute("style") || "")) {
      clone.setAttribute("style", cssUrls(clone.getAttribute("style"), document.baseURI));
    }

    if (tag === "script" || tag === "base" || (tag === "link" && /preload|prefetch|modulepreload|manifest/i.test(element.rel))) {
      removals.push(clone);
    } else if (tag === "meta" && (element.hasAttribute("charset") || /content-type|content-security-policy/i.test(element.httpEquiv))) {
      removals.push(clone);
    } else if (tag === "link" && /stylesheet/i.test(element.rel) && element.href) {
      const style = document.createElement("style");
      if (element.media) style.media = element.media;
      try {
        style.textContent = safeCss(sheetText(element.sheet, element.href));
      } catch {
        style.textContent = `fps-css:${externalCss.length}`;
        externalCss.push(element.href);
      }
      replacements.push([clone, style]);
    } else if (tag === "link" && /icon/i.test(element.rel) && element.href) {
      clone.setAttribute("href", token(element.href));
    } else if (tag === "style") {
      try {
        clone.textContent = safeCss(sheetText(element.sheet, document.baseURI));
      } catch {
        clone.textContent = safeCss(cssUrls(element.textContent, document.baseURI));
      }
    } else if (tag === "img") {
      const source = element.currentSrc || element.dataset.src || element.dataset.lazySrc || element.src;
      if (source) clone.setAttribute("src", token(source));
      clone.removeAttribute("srcset");
      clone.removeAttribute("sizes");
      clone.removeAttribute("loading");
    } else if (tag === "source" && element.parentElement?.localName === "picture") {
      removals.push(clone);
    } else if (tag === "video" && element.poster) {
      clone.setAttribute("poster", token(element.poster));
    } else if (tag === "a" && element.getAttribute("href") && !element.getAttribute("href").startsWith("#")) {
      clone.setAttribute("href", element.href);
    } else if (tag === "iframe" && element.src) {
      clone.setAttribute("src", element.src);
    } else if (tag === "input") {
      if (/checkbox|radio/i.test(element.type)) {
        if (element.checked) clone.setAttribute("checked", "");
        else clone.removeAttribute("checked");
      } else if (element.type !== "password") {
        clone.setAttribute("value", element.value);
      }
    } else if (tag === "textarea") {
      clone.textContent = element.value;
    } else if (tag === "select") {
      const optionCopies = clone.querySelectorAll("option");
      Array.from(element.options).forEach((option, optionIndex) => {
        const optionCopy = optionCopies[optionIndex];
        if (!optionCopy) return;
        if (option.selected) optionCopy.setAttribute("selected", "");
        else optionCopy.removeAttribute("selected");
      });
      if (element.options.length > 1) {
        // Lista visible con todas las opciones del desplegable.
        const list = document.createElement("ul");
        list.className = "fps-options";
        Array.from(element.options).forEach(option => {
          const item = document.createElement("li");
          item.textContent = option.text;
          if (option.selected) item.className = "fps-selected";
          list.append(item);
        });
        clone.after(list);
      }
    } else if (tag === "canvas") {
      try {
        const image = document.createElement("img");
        image.src = element.toDataURL("image/png");
        image.className = element.className;
        image.style.cssText = `width:${element.clientWidth}px;height:${element.clientHeight}px`;
        replacements.push([clone, image]);
      } catch {}
    }

    if (tag !== "html" && element.scrollHeight > element.clientHeight + 8
      && /auto|scroll|hidden/.test(getComputedStyle(element).overflowY)) {
      clone.classList.add("fps-grow");
      for (let parent = clone.parentElement; parent && parent !== copy; parent = parent.parentElement) {
        parent.classList.add("fps-grow");
      }
    }
  });
  removals.forEach(element => element.remove());
  replacements.forEach(([from, to]) => from.replaceWith(to));

  const head = copy.querySelector("head") || copy.insertBefore(document.createElement("head"), copy.firstChild);
  if (document.adoptedStyleSheets?.length) {
    try {
      const adopted = document.createElement("style");
      adopted.textContent = safeCss(document.adoptedStyleSheets.map(sheet => sheetText(sheet, document.baseURI)).join("\n"));
      head.append(adopted);
    } catch {}
  }
  const charset = document.createElement("meta");
  charset.setAttribute("charset", "utf-8");
  head.prepend(charset);
  const extra = document.createElement("style");
  extra.textContent = `
    ul.fps-options{margin:4px 0 8px;padding:6px 10px 6px 26px;border:1px dashed #9aa4b2;border-radius:6px;font-size:12px;background:#f7f8fa;color:#222}
    ul.fps-options .fps-selected{font-weight:700}
    @media print{
      html,body{height:auto!important;overflow:visible!important}
      .fps-grow{height:auto!important;max-height:none!important;overflow:visible!important}
      *{-webkit-print-color-adjust:exact;print-color-adjust:exact}
    }`;
  head.append(extra);

  const note = `<!-- Guardado con FullPage Saver desde ${location.href.replace(/--/g, "")} el ${new Date().toISOString()} -->\n`;
  return {
    html: `<!DOCTYPE html>\n${note}${copy.outerHTML}`,
    urls,
    externalCss,
    title: document.title
  };
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

async function runLimited(items, limit, worker) {
  let next = 0;
  const runners = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) {
      const current = next++;
      await worker(items[current], current);
    }
  });
  await Promise.all(runners);
}

async function buildHtml(tab) {
  setStatus("Copiando el contenido de la página…");
  const [result] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: snapshotPageInTab
  });
  const snapshot = result?.result;
  if (!snapshot?.html) {
    throw new Error("No se pudo leer el contenido de la página.");
  }

  const { urls } = snapshot;
  const index = new Map(urls.map((url, position) => [url, position]));
  const token = (value, base) => {
    let absolute;
    try {
      absolute = new URL(value, base).href;
    } catch {
      return value;
    }
    if (!/^https?:/i.test(absolute)) return absolute;
    if (!index.has(absolute)) {
      index.set(absolute, urls.length);
      urls.push(absolute);
    }
    return `fps-res:${index.get(absolute)}`;
  };
  const cssUrls = (text, base) => text.replace(
    /url\(\s*(['"]?)([^'")]+)\1\s*\)/g,
    (match, quote, value) => (/^(data|blob|#)/i.test(value.trim()) ? match : `url("${token(value.trim(), base)}")`)
  );
  const fetchCss = async (url, depth = 0) => {
    try {
      const response = await fetch(url, { credentials: "include" });
      if (!response.ok) return "";
      let text = await response.text();
      if (depth < 2) {
        const imports = [...text.matchAll(/@import\s+(?:url\()?\s*['"]?([^'")\s;]+)['"]?\s*\)?[^;]*;/g)];
        for (const match of imports) {
          text = text.replace(match[0], await fetchCss(new URL(match[1], url).href, depth + 1));
        }
      }
      return cssUrls(text, url);
    } catch {
      return "";
    }
  };

  setStatus(`Descargando ${snapshot.externalCss.length} hojas de estilo…`);
  const cssTexts = await Promise.all(snapshot.externalCss.map(url => fetchCss(url)));

  const dataUrls = new Array(urls.length);
  let done = 0;
  await runLimited(urls, 6, async (url, position) => {
    try {
      const response = await fetch(url, { credentials: "include" });
      if (response.ok) dataUrls[position] = await blobToDataUrl(await response.blob());
    } catch {}
    done++;
    if (done % 5 === 0 || done === urls.length) {
      setStatus(`Incrustando imágenes y fuentes: ${done} de ${urls.length}…`);
    }
  });

  setStatus("Generando el archivo HTML…");
  const html = snapshot.html
    .replace(/fps-css:(\d+)/g, (match, position) => (cssTexts[position] || "").replace(/<\/style/gi, "<\\/style"))
    .replace(/fps-res:(\d+)/g, (match, position) => dataUrls[position] || urls[position] || "");
  return { html, title: snapshot.title || tab.title };
}

// ---------- Descargas ----------

async function download(blob, filename) {
  const objectUrl = URL.createObjectURL(blob);
  // Esta ventana sigue abierta, así que la URL vive hasta que termine la descarga.
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 10 * 60_000);
  const downloadId = await chrome.downloads.download({ url: objectUrl, filename, saveAs: true });
  if (downloadId === undefined) {
    throw new Error("Chrome no inició la descarga.");
  }
}

async function run() {
  const tab = await getTargetTab();
  document.querySelector("#page-title").textContent = tab.title || tab.url;

  if (MODE === "mht") {
    setStatus("Chrome está preparando el archivo web MHT…");
    const archive = await chrome.pageCapture.saveAsMHTML({ tabId: tab.id });
    if (!archive?.size) throw new Error("Chrome no devolvió una copia de la página.");
    await download(new Blob([archive], { type: "multipart/related" }), `${safeFileName(tab.title || "pagina-web")}.mht`);
    return "Archivo MHT listo. Elige dónde guardarlo en el diálogo de Chrome.";
  }

  await preparePage(tab.id);

  if (MODE === "pdf") {
    setStatus("Capturando la página completa… no cambies de pestaña.");
    const captureResult = await captureFullPage(tab);
    setStatus(`Se capturaron ${captureResult.captures.length} pantallas. Generando el PDF…`);
    const pdf = await createPdf(captureResult, ORIENTATION);
    await download(pdf, `${safeFileName(captureResult.title)}.pdf`);
    return `PDF generado (${captureResult.captures.length} capturas). Elige dónde guardarlo.`;
  }

  const { html, title } = await buildHtml(tab);
  await download(new Blob([html], { type: "text/html;charset=utf-8" }), `${safeFileName(title)}.html`);
  return "HTML listo. Para el PDF: ábrelo en Chrome, pulsa Ctrl+P y elige «Guardar como PDF».";
}

document.querySelector("#close").addEventListener("click", () => window.close());

run()
  .then(message => {
    setStatus(message);
    document.body.dataset.state = "done";
  })
  .catch(error => {
    setStatus(`No se pudo completar: ${error.message || "error desconocido de Chrome."}`, true);
    document.body.dataset.state = "error";
  });
