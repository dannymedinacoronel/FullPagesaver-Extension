const summary = document.querySelector("#summary");
const status = document.querySelector("#status");
const pagesElement = document.querySelector("#pages");
const printButton = document.querySelector("#print");
const deleteButton = document.querySelector("#delete-job");
const fileSelect = document.querySelector("#file-select");
const jobId = new URLSearchParams(location.search).get("job");

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("pagina-completa-pdf", 1);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error(t("pv.dbOpen")));
  });
}

async function readJob(id) {
  const database = await openDatabase();
  try {
    return await new Promise((resolve, reject) => {
      const request = database.transaction("jobs", "readonly").objectStore("jobs").get(id);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error(t("pv.dbRead")));
    });
  } finally {
    database.close();
  }
}

async function deleteJob(id) {
  const database = await openDatabase();
  try {
    await new Promise((resolve, reject) => {
      const transaction = database.transaction("jobs", "readwrite");
      transaction.objectStore("jobs").delete(id);
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error || new Error(t("pv.dbDelete")));
    });
  } finally {
    database.close();
  }
}

function pageDimensions(paper, orientation) {
  const sizes = {
    A4: [210, 297],
    Letter: [215.9, 279.4],
    A3: [297, 420],
    Legal: [215.9, 355.6]
  };
  const [shortSide, longSide] = sizes[paper] || sizes.A4;
  return orientation === "landscape"
    ? [longSide, shortSide]
    : [shortSide, longSide];
}

function getOutputFiles(job) {
  if (Array.isArray(job.files) && job.files.length) return job.files;
  return [{ name: job.title, pages: job.pages || [] }];
}

function updateSelectedFile(job, files, failuresByFile) {
  const selectedIndex = Number(fileSelect.value) || 0;
  const file = files[selectedIndex];
  if (!file) {
    printButton.disabled = true;
    summary.textContent = t("pv.noFiles");
    status.textContent = t("pv.goBack");
    return;
  }

  for (const page of pagesElement.children) {
    page.hidden = page.dataset.fileIndex !== String(selectedIndex);
  }
  const failures = failuresByFile[selectedIndex] || 0;
  const pageCount = file.pages.length;
  summary.textContent = job.files
    ? t("pv.summaryMulti", { i: selectedIndex + 1, total: files.length, pages: pageCount, name: file.name })
    : t("pv.summary", { pages: pageCount, name: file.name });
  document.title = `${file.name.replace(/\.[^.]+$/, "")} - PDF`;
  status.textContent = failures
    ? t("pv.failed", { n: failures })
    : t("pv.ready");
  printButton.disabled = failures > 0 || pageCount === 0;
  printButton.textContent = t("pv.save");
}

async function renderJob(job) {
  const [width, height] = pageDimensions(job.options.paper, job.options.orientation);
  document.documentElement.style.setProperty("--sheet-width", `${width}mm`);
  document.documentElement.style.setProperty("--sheet-height", `${height}mm`);
  document.documentElement.style.setProperty("--sheet-margin", `${job.options.margin}mm`);
  document.documentElement.style.setProperty(
    "--image-fit",
    job.options.fit === "cover" ? "cover" : "contain"
  );
  const orientation = job.options.orientation === "landscape" ? "landscape" : "portrait";
  const printStyle = document.createElement("style");
  printStyle.textContent = `@page { size: ${job.options.paper} ${orientation}; margin: 0; }`;
  document.head.append(printStyle);

  const files = getOutputFiles(job);
  if (job.files) {
    fileSelect.replaceChildren();
    for (const [index, file] of files.entries()) {
      fileSelect.add(new Option(`${index + 1}. ${file.name}`, String(index)));
    }
    fileSelect.hidden = false;
  }

  const failuresByFile = new Array(files.length).fill(0);
  await Promise.all(files.flatMap((file, fileIndex) =>
    file.pages.map((pageData, pageIndex) => new Promise(resolve => {
      const page = document.createElement("section");
      page.className = "page";
      if (pageIndex === file.pages.length - 1) {
        page.classList.add("is-last-in-file");
      }
      page.dataset.fileIndex = String(fileIndex);
      page.setAttribute("aria-label", t("pv.pageLabel", { name: file.name, n: pageIndex + 1 }));
      const image = document.createElement("img");
      image.src = pageData.src;
      image.alt = t("pv.pageLabel", { name: file.name, n: pageIndex + 1 });
      image.addEventListener("load", () => resolve(), { once: true });
      image.addEventListener("error", () => {
        failuresByFile[fileIndex]++;
        resolve();
      }, { once: true });
      page.append(image);
      pagesElement.append(page);
    }))
  ));

  fileSelect.value = "0";
  updateSelectedFile(job, files, failuresByFile);
  fileSelect.addEventListener("change", () => {
    updateSelectedFile(job, files, failuresByFile);
  });
}

printButton.addEventListener("click", () => window.print());

deleteButton.addEventListener("click", async () => {
  if (!jobId) return;
  deleteButton.disabled = true;
  try {
    await deleteJob(jobId);
    pagesElement.replaceChildren();
    fileSelect.replaceChildren();
    fileSelect.hidden = true;
    printButton.disabled = true;
    summary.textContent = t("pv.deleted");
    status.textContent = t("pv.deletedDesc");
  } catch (error) {
    status.textContent = t("pv.deleteError", { msg: error.message });
    deleteButton.disabled = false;
  }
});

async function init() {
  if (!jobId) {
    summary.textContent = t("pv.noJob");
    status.textContent = t("pv.goBack");
    return;
  }

  try {
    const job = await readJob(jobId);
    if (!job) {
      summary.textContent = t("pv.gone");
      status.textContent = t("pv.goBack");
      return;
    }
    await renderJob(job);
  } catch (error) {
    summary.textContent = t("pv.openError");
    status.textContent = error.message;
  }
}

init();
