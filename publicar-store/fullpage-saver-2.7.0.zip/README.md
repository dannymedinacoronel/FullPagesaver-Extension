# FullPage Saver

Extensión de Chrome Manifest V3 para:

- Guardar la pestaña web activa como archivo `.mhtml` usando la captura integrada de Chrome. El archivo reúne la página y los recursos que Chrome tenga cargados; se guarda localmente y se puede abrir en Chrome.
- Recorrer la pestaña activa, capturar su contenido visible en pantallas consecutivas y generar directamente un archivo PDF descargable.
- Exportar las páginas visibles de elementos `canvas` como un HTML autocontenido compatible con el conversor PDF de esta extensión.
- Importar uno o varios HTML guardados con imágenes de páginas serializadas en `canvas`, reordenarlos con arrastrar y soltar o con los botones de flecha, y preparar una vista de impresión para guardarlos como PDF.

## Instalar en Chrome

1. Abre `chrome://extensions`.
2. Activa **Modo de desarrollador**.
3. Pulsa **Cargar descomprimida** y selecciona esta carpeta `extension-chrome`. Chrome mostrará los permisos que necesita la extensión para capturar la pestaña y descargar la copia. Si ya la habías instalado, pulsa el botón de recarga para instalar la versión 2.7.0.
4. Fija **FullPage Saver** en la barra de extensiones.
5. Abre la página, pulsa el icono de la extensión y elige **Guardar la página completa como PDF**. La extensión captura las pantallas mientras recorre la página, compone un PDF y abre el diálogo de Chrome para elegir dónde guardar el archivo. Puedes elegir papel y orientación antes de iniciar.
6. Para guardar una copia de archivo web en vez de PDF, selecciona **Archivar página web (.mht)**.

Para los PDF, abre la extensión, elige **Crear PDF desde HTML guardados**, añade archivos con el selector o arrástralos a la zona de carga y configura las opciones. En **Archivos de salida**, puedes elegir un único PDF combinado o **PDF independiente por cada archivo**. Pulsa **Preparar vista previa**. En el modo independiente, la nueva pestaña muestra un selector de archivo; elige el que quieras y pulsa **Guardar este PDF**. Chrome preguntará dónde guardarlo. Repite con cada archivo que quieras exportar; puedes dejar sin guardar los demás.

## Vista previa antes de guardar

Antes de generar el HTML o el PDF, la ventana de progreso se amplía y muestra la vista previa real de lo que se va a guardar. A la izquierda se puede:

- Elegir **Página completa** o **Solo el contenido** (quita cabecera, menús, barras laterales, pie, comentarios, cookies, publicidad y elementos flotantes).
- Marcar o desmarcar **partes de la página** detectadas: cabecera, menús, barras laterales, pie, comentarios, avisos de cookies, publicidad, botones flotantes, vídeos e imágenes. Las cookies, la publicidad y los botones flotantes vienen desmarcados.
- Marcar o desmarcar **secciones**, detectadas por los títulos (h1–h3) del contenido principal, con su jerarquía. Pulsar el nombre de una sección la muestra en la vista previa.
- **Añadir al documento**: portada con título, dirección y fecha; índice de secciones con enlaces; la dirección de cada enlace junto al texto; y una nota personal al principio.

En el PDF desde un visor (PDF.js) la vista previa muestra las páginas en miniatura para elegir cuáles incluir (también por rango, por ejemplo «1-3, 5») y se puede añadir portada y nota. En el HTML solo se incrustan los recursos de lo que se guarda. Al terminar, la pestaña queda exactamente como estaba. Código: `review.js`, `review.css` y las funciones `analyzeSectionsInTab`, `applyChoicesInTab` y `clearChoicesInTab` de `save.js`.

## Idiomas

La primera vez que se abre la extensión aparece una pantalla para elegir idioma: español, català, English, français, português, Deutsch o italiano. Toda la interfaz (popup, ventana de progreso, conversor, vista previa y aviso legal) usa ese idioma y se puede cambiar en cualquier momento con el selector «🌐 Idioma» del popup. La elección se guarda en el almacenamiento local de la extensión. Los textos están en `i18n.js` (cada texto con sus 7 traducciones en el orden de `LANGS`) y el aviso legal en `legal-i18n.js`. El nombre y la descripción que muestra Chrome se traducen con `_locales` según el idioma del navegador.

## Temas

El selector de la paleta del popup cambia el aspecto de todas las pantallas: **Moderno** (degradado verde azulado e índigo, con partículas de luz), **Clásico** (el diseño anterior, plano en blanco y azul, sin partículas) y **Rosa** (degradado rosa con destellos). Moderno y Rosa siguen el modo oscuro del sistema. La elección se guarda en el almacenamiento local de la extensión y las páginas abiertas se actualizan al momento. Las partículas se pausan cuando la pestaña no está visible y se quedan quietas si el sistema pide reducir el movimiento. Todo está en `theme.js` y en los bloques `[data-theme]` de cada hoja de estilos.

## Webs tipo aplicación (Gmail, Drive…)

Antes de actuar, la extensión detecta si la página es una «aplicación»: webs conocidas (Gmail, Google Drive/Docs/Calendar, Outlook, Teams, OneDrive, Slack, WhatsApp, Telegram, Discord, Notion, Trello, Figma, Asana, Atlassian y redes sociales) o cualquier página que no hace scroll pero tiene varios paneles con scroll propio o muchos iframes visibles. En ese modo no pulsa ningún botón, recorre solo el panel principal con un límite corto, no copia los iframes ocultos y, si la lista es infinita, entrega el PDF con las primeras 15 pantallas en vez de fallar. En las webs normales los clics también son prudentes: nunca toca menús, barras de herramientas, navegación, pestañas, diálogos ni botones que abren ventanas emergentes, con un máximo de 60 clics y 40 pantallas por panel.

## Notas

- El archivo MHTML lo genera Chrome con `chrome.pageCapture.saveAsMHTML`; representa la pestaña y los recursos capturados por Chrome, no todos los resultados posibles de controles interactivos. Una lista desplegable que hace nuevas llamadas solo muestra los datos de la opción abierta y cargada en el momento de guardar. Para conservar varias opciones, guárdalas desde la función de exportación original de la aplicación o desde su fuente/servidor autorizado.
- El PDF directo se compone en el navegador. Si el área desplazable es un visor de páginas (PDF.js y similares, también dentro de iframes del mismo origen), cada página se copia de su propio canvas a su tamaño original: sin uniones ni barras repetidas. En el resto de páginas se une una serie de capturas consecutivas del área visible; los elementos fijos (cabeceras, botones flotantes) solo aparecen en la primera captura. Mantén Chrome en primer plano y no cambies de pestaña mientras captura. La ventana de progreso espera a que Chrome termine de guardar el archivo: si se cierra antes, el archivo puede quedar vacío o cortado. El diseño queda como imagen, no como texto seleccionable. Por seguridad y memoria, el límite es de 120 pantallas.
- El HTML se guarda como SavePage WE: un único archivo .html sin scripts, con estilos, imágenes y fuentes incrustados, el contenido de los iframes del mismo origen dentro de `srcdoc` y cada `canvas` guardado como imagen. En visores tipo PDF.js se recorren todas las páginas para guardarlas aunque el visor ya las haya descargado. Es compatible con el conversor PDF de esta extensión. Los iframes de otros dominios se mantienen con su dirección original.
- Para la conversión a PDF, cada imagen guardada en el HTML se ajusta a una hoja. Los controles del diálogo de impresión (por ejemplo, destino y escala) siguen perteneciendo a Chrome.
- Permisos: para leer, recorrer y capturar la pestaña basta `activeTab` (se concede al abrir la extensión). El acceso a todos los sitios es opcional: solo se pide, con un botón, al guardar en HTML, para incrustar imágenes, estilos y fuentes de otros dominios. Sin él, esos recursos quedan enlazados en la copia.
- La extensión no envía archivos ni páginas a un servidor. Los datos de la vista previa se guardan en IndexedDB local de la extensión; usa **Eliminar datos temporales** al terminar si quieres borrarlos.

## Aviso legal

FullPage Saver es una extensión gratuita de **Danny Medina Coronel** (empresademkor@gmail.com), que actúa como particular. Se ofrece «tal cual», sin garantías. El usuario es el único responsable del uso que haga de la extensión y de las copias que genere: debe guardar solo contenido sobre el que tenga derechos o permiso, respetar la propiedad intelectual y los términos de cada sitio, y no eludir medidas de protección ni restricciones de acceso. En la máxima medida permitida por la ley, el titular no se hace responsable de usos indebidos ni de los daños derivados del uso de la extensión. El texto completo, con la política de privacidad, está en `legal.html` (enlazado desde el popup).
