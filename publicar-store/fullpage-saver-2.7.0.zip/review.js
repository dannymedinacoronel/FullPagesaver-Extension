// Vista previa antes de guardar: el usuario elige qué partes y secciones
// incluir y puede añadir portada, índice, direcciones de enlaces y una nota.
// Lo usa save.js en la ventana de progreso, que se amplía mientras tanto.

const PART_ORDER = ["header", "nav", "aside", "footer", "comments", "cookies", "ads", "floating", "media", "images"];
// Por sentido común, lo que casi nadie quiere guardar viene desmarcado.
const DEFAULT_HIDDEN_PARTS = ["cookies", "ads", "floating"];
const READER_HIDDEN_PARTS = ["header", "nav", "aside", "footer", "comments", "cookies", "ads", "floating"];

const escapeHtml = value => String(value).replace(/[&<>"']/g, char => (
  { "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[char]
));

// ---------- Aplicar la selección ----------

function choicesSelectors(choices) {
  const selectors = choices.excludedSections.map(id => `[data-fps-sec~="${id}"]`);
  for (const part of choices.hiddenParts) {
    if (part === "images") selectors.push("img", "picture");
    else selectors.push(`[data-fps-part="${part}"]`);
  }
  return selectors;
}

const LINKS_CSS = "a[href^=\"http\"]::after { content: \" (\" attr(href) \")\"; font-size: .8em; font-weight: normal; color: #5b6475; word-break: break-all; }";

// CSS que oculta lo desmarcado: para la vista previa y para capturar el PDF.
function choicesCss(choices) {
  const rules = [];
  const selectors = choicesSelectors(choices);
  if (selectors.length) rules.push(`${selectors.join(",\n")} { display: none !important; }`);
  if (choices.extras.links) rules.push(LINKS_CSS);
  return rules.join("\n");
}

function includedSections(info, choices) {
  return info.sections.filter(section => !choices.excludedSections.includes(section.id));
}

// Bloque de portada, nota e índice que se añade al principio del HTML.
function extrasHtml(info, choices) {
  const { cover, toc } = choices.extras;
  const note = choices.extras.note ? choices.extras.noteText.trim() : "";
  const sections = includedSections(info, choices);
  if (!cover && !note && !(toc && sections.length)) return "";
  const font = "font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;";
  let html = `<div id="fps-extras" style="${font} box-sizing: border-box; max-width: 900px; margin: 24px auto 32px; padding: 28px 32px; border: 1px solid #dfe3ee; border-radius: 16px; background: #ffffff; color: #0f172a; line-height: 1.5; text-align: left;">`;
  if (cover) {
    html += `<div style="height: 6px; margin: -28px -32px 22px; border-radius: 16px 16px 0 0; background: linear-gradient(90deg, #14b8a6, #4f46e5);"></div>`;
    html += `<div style="font-size: 28px; font-weight: 800; letter-spacing: -.02em; line-height: 1.2;">${escapeHtml(info.title || "")}</div>`;
    html += `<div style="margin-top: 8px; font-size: 13px; color: #475569;">${escapeHtml(t("cover.source"))}: <a href="${escapeHtml(info.url || "")}" style="color: #4f46e5; word-break: break-all;">${escapeHtml(info.url || "")}</a></div>`;
    html += `<div style="margin-top: 2px; font-size: 13px; color: #475569;">${escapeHtml(t("cover.saved", { date: new Date().toLocaleString(currentLang) }))}</div>`;
  }
  if (note) {
    html += `<div style="margin-top: 18px; padding: 14px 16px; border-left: 4px solid #f59e0b; border-radius: 8px; background: #fff8eb; color: #3f2d07;"><div style="font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: .06em;">${escapeHtml(t("cover.note"))}</div><div style="margin-top: 4px; font-size: 15px;">${escapeHtml(note).replace(/\n/g, "<br>")}</div></div>`;
  }
  if (toc && sections.length) {
    const minLevel = Math.min(...sections.map(section => section.level));
    html += `<div style="margin-top: 20px; font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: .06em; color: #475569;">${escapeHtml(t("cover.toc"))}</div>`;
    html += sections.map(section => `<div style="padding: 3px 0 3px ${(section.level - minLevel) * 18}px; font-size: 15px;"><a href="#fps-${section.id}" data-fps-toc="${section.id}" style="color: #1e293b; text-decoration: none;">${escapeHtml(section.label)}</a></div>`).join("");
  }
  return `${html}</div>`;
}

// Transformación de cada marco del HTML final: quita lo desmarcado y añade
// los extras. Se hace antes de incrustar recursos, así no se descarga nada
// de lo que no se va a guardar.
function choicesTransform(info, choices) {
  const selectors = choicesSelectors(choices).join(",");
  return (html, position) => {
    if (position !== 0 && !selectors && !choices.extras.links) return html;
    const doc = new DOMParser().parseFromString(html, "text/html");
    if (selectors) doc.querySelectorAll(selectors).forEach(element => element.remove());
    if (choices.extras.links) {
      const style = doc.createElement("style");
      style.textContent = LINKS_CSS;
      doc.head.append(style);
    }
    if (position === 0) {
      // Anclas para el índice.
      doc.querySelectorAll("[data-fps-head]").forEach(heading => {
        const anchor = doc.createElement("a");
        anchor.id = `fps-${heading.getAttribute("data-fps-head")}`;
        heading.prepend(anchor);
      });
      const extras = extrasHtml(info, choices);
      if (extras) doc.body.insertAdjacentHTML("afterbegin", extras);
    }
    const prefix = html.match(/^\s*<!DOCTYPE[^>]*>\s*(<!--[\s\S]*?-->\s*)?/i)?.[0] || "<!DOCTYPE html>\n";
    return prefix + doc.documentElement.outerHTML;
  };
}

// ---------- Portada como imagen (para los PDF) ----------

async function makeCoverPage(info, choices, sections, ratio = 297 / 210) {
  const width = 1240;
  const height = Math.round(width * ratio);
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const g = canvas.getContext("2d");
  g.fillStyle = "#ffffff";
  g.fillRect(0, 0, width, height);
  const band = g.createLinearGradient(0, 0, width, 0);
  band.addColorStop(0, "#14b8a6");
  band.addColorStop(1, "#4f46e5");
  g.fillStyle = band;
  g.fillRect(0, 0, width, 18);

  const margin = 110;
  const maxWidth = width - margin * 2;
  let y = 170;
  const font = (weight, size) => `${weight} ${size}px "Segoe UI", system-ui, sans-serif`;
  const wrap = (text, size, weight) => {
    g.font = font(weight, size);
    const lines = [];
    for (const paragraph of String(text).split("\n")) {
      let line = "";
      for (const word of paragraph.split(/\s+/)) {
        const test = line ? `${line} ${word}` : word;
        if (g.measureText(test).width <= maxWidth) {
          line = test;
          continue;
        }
        if (g.measureText(word).width <= maxWidth) {
          lines.push(line);
          line = word;
          continue;
        }
        // Palabras más anchas que la línea (direcciones): se cortan por caracteres.
        let chunk = line ? `${line} ` : "";
        for (const char of word) {
          if (g.measureText(chunk + char).width > maxWidth && chunk) {
            lines.push(chunk);
            chunk = "";
          }
          chunk += char;
        }
        line = chunk;
      }
      lines.push(line);
    }
    return lines;
  };
  const draw = (text, size, weight, color, gap = 1.3) => {
    for (const line of wrap(text, size, weight)) {
      if (y > height - 120) return false;
      g.font = font(weight, size);
      g.fillStyle = color;
      g.fillText(line, margin, y);
      y += size * gap;
    }
    return true;
  };

  if (choices.extras.cover) {
    draw(info.title || "", 58, 800, "#0f172a", 1.18);
    y += 18;
    draw(`${t("cover.source")}: ${info.url || ""}`, 24, 500, "#4f46e5");
    draw(t("cover.saved", { date: new Date().toLocaleString(currentLang) }), 24, 500, "#64748b");
    y += 30;
  }
  const note = choices.extras.note ? choices.extras.noteText.trim() : "";
  if (note) {
    const lines = wrap(note, 26, 500);
    const boxHeight = Math.min(lines.length, 12) * 26 * 1.4 + 70;
    g.fillStyle = "#fff8eb";
    g.fillRect(margin - 24, y - 40, maxWidth + 48, boxHeight);
    g.fillStyle = "#f59e0b";
    g.fillRect(margin - 24, y - 40, 8, boxHeight);
    draw(t("cover.note").toUpperCase(), 20, 700, "#92400e");
    for (const line of lines.slice(0, 12)) draw(line, 26, 500, "#3f2d07", 1.4);
    y += 40;
  }
  if (choices.extras.toc && sections.length) {
    draw(t("cover.toc").toUpperCase(), 22, 700, "#475569");
    y += 6;
    const minLevel = Math.min(...sections.map(section => section.level));
    for (const section of sections) {
      if (y > height - 140) {
        draw("…", 26, 500, "#64748b");
        break;
      }
      g.font = font(section.level === minLevel ? 650 : 500, 26);
      g.fillStyle = "#1e293b";
      let label = section.label;
      const indent = (section.level - minLevel) * 34;
      while (g.measureText(label).width > maxWidth - indent && label.length > 4) label = `${label.slice(0, -2)}…`;
      g.fillText(label, margin + indent, y);
      y += 40;
    }
  }
  g.font = font(600, 18);
  g.fillStyle = "#94a3b8";
  g.fillText("FullPage Saver", margin, height - 60);
  return { dataUrl: canvas.toDataURL("image/jpeg", 0.92), width, height };
}

// ---------- Interfaz ----------

function setReviewVisible(visible) {
  document.body.classList.toggle("reviewing", visible);
  document.querySelector("#review").hidden = !visible;
}

function checkboxRow({ id, label, count, checked, level = 0, extraClass = "", action = "" }) {
  return `<label class="rv-row ${extraClass}" style="--level: ${level}">
    <input type="checkbox" data-id="${escapeHtml(id)}" ${checked ? "checked" : ""}>
    <span class="rv-label" ${action ? `data-action="${action}" data-target="${escapeHtml(id)}"` : ""}>${escapeHtml(label)}</span>
    ${count ? `<span class="rv-count">${count}</span>` : ""}
  </label>`;
}

function extrasBlock(hasSections) {
  return `<section class="rv-group">
      <h3>${escapeHtml(t("rv.extras"))}</h3>
      ${checkboxRow({ id: "cover", label: t("ex.cover"), checked: false })}
      ${hasSections ? checkboxRow({ id: "toc", label: t("ex.toc"), checked: false }) : ""}
      ${checkboxRow({ id: "links", label: t("ex.links"), checked: false })}
      ${checkboxRow({ id: "note", label: t("ex.note"), checked: false })}
      <textarea id="rv-note" rows="3" placeholder="${escapeHtml(t("ex.notePlaceholder"))}" hidden></textarea>
    </section>`;
}

// Vista previa de una página web: devuelve la selección o null si se cancela.
function openReview({ mode, info, previewHtml }) {
  return new Promise(resolve => {
    const side = document.querySelector("#rv-side");
    const frame = document.querySelector("#rv-frame");
    const pagesGrid = document.querySelector("#rv-pages");
    const summary = document.querySelector("#rv-summary");
    const saveButton = document.querySelector("#rv-save");
    const error = document.querySelector("#rv-error");
    pagesGrid.hidden = true;
    frame.hidden = false;
    error.textContent = "";

    const partCount = part => (part === "images" ? info.images : info.parts[part]) || 0;
    const parts = PART_ORDER.filter(part => partCount(part) > 0);
    const state = {
      hiddenParts: new Set(DEFAULT_HIDDEN_PARTS.filter(part => parts.includes(part))),
      excludedSections: new Set(),
      extras: { cover: false, toc: false, links: false, note: false, noteText: "" }
    };
    const choices = () => ({
      hiddenParts: [...state.hiddenParts],
      excludedSections: [...state.excludedSections],
      extras: { ...state.extras }
    });

    side.innerHTML = `
      <div class="rv-presets" role="group">
        <button type="button" class="rv-preset" data-preset="full">${escapeHtml(t("rv.presetFull"))}</button>
        <button type="button" class="rv-preset" data-preset="reader">${escapeHtml(t("rv.presetReader"))}</button>
      </div>
      ${parts.length ? `<section class="rv-group" data-group="parts"><h3>${escapeHtml(t("rv.parts"))}</h3>
        ${parts.map(part => checkboxRow({ id: `part:${part}`, label: t(`part.${part}`), count: partCount(part), checked: !state.hiddenParts.has(part) })).join("")}
      </section>` : ""}
      <section class="rv-group" data-group="sections">
        <div class="rv-group-head"><h3>${escapeHtml(t("rv.sections"))}</h3>
          ${info.sections.length ? `<span><button type="button" class="rv-link" data-all="1">${escapeHtml(t("rv.all"))}</button> · <button type="button" class="rv-link" data-all="0">${escapeHtml(t("rv.none"))}</button></span>` : ""}
        </div>
        ${info.sections.length
          ? `<div class="rv-sections">${info.sections.map(section => checkboxRow({ id: `sec:${section.id}`, label: section.label, level: Math.max(0, section.level - Math.min(...info.sections.map(s => s.level))), checked: true, action: "goto" })).join("")}</div>`
          : `<p class="rv-empty">${escapeHtml(t("rv.noSections"))}</p>`}
      </section>
      ${extrasBlock(info.sections.length > 0)}`;

    const note = side.querySelector("#rv-note");
    const frameDocs = () => {
      const docs = [];
      const visit = doc => {
        if (!doc?.documentElement) return;
        docs.push(doc);
        doc.querySelectorAll("iframe").forEach(inner => {
          try {
            visit(inner.contentDocument);
          } catch {}
        });
      };
      try {
        visit(frame.contentDocument);
      } catch {}
      return docs;
    };

    const update = () => {
      const current = choices();
      const css = choicesCss(current);
      for (const doc of frameDocs()) {
        let style = doc.getElementById("fps-choices");
        if (!style) {
          style = doc.createElement("style");
          style.id = "fps-choices";
          (doc.head || doc.documentElement).append(style);
        }
        style.textContent = css;
      }
      const top = frame.contentDocument;
      if (top?.body) {
        top.getElementById("fps-extras")?.remove();
        const extras = extrasHtml(info, current);
        if (extras) top.body.insertAdjacentHTML("afterbegin", extras);
      }
      const included = includedSections(info, current).length;
      summary.textContent = info.sections.length
        ? t("rv.summary", { n: included, total: info.sections.length })
        : t("rv.subtitle");
      side.querySelectorAll("[data-preset]").forEach(button => {
        const hidden = button.dataset.preset === "reader" ? READER_HIDDEN_PARTS : DEFAULT_HIDDEN_PARTS;
        const expected = new Set(hidden.filter(part => parts.includes(part)));
        const active = expected.size === state.hiddenParts.size && [...expected].every(part => state.hiddenParts.has(part));
        button.classList.toggle("is-active", active);
      });
      saveButton.textContent = mode === "pdf" ? t("rv.savePdf") : t("rv.saveHtml");
    };

    const syncChecks = () => {
      side.querySelectorAll("input[type=checkbox]").forEach(input => {
        const [kind, value] = input.dataset.id.split(":");
        if (kind === "part") input.checked = !state.hiddenParts.has(value);
        if (kind === "sec") input.checked = !state.excludedSections.has(value);
      });
    };

    side.onchange = event => {
      const input = event.target.closest("input[type=checkbox]");
      if (!input) return;
      const [kind, value] = input.dataset.id.split(":");
      if (kind === "part") {
        if (input.checked) state.hiddenParts.delete(value);
        else state.hiddenParts.add(value);
      } else if (kind === "sec") {
        if (input.checked) state.excludedSections.delete(value);
        else state.excludedSections.add(value);
      } else {
        state.extras[kind] = input.checked;
        if (kind === "note") {
          note.hidden = !input.checked;
          if (input.checked) note.focus();
        }
      }
      error.textContent = "";
      update();
    };
    note.oninput = () => {
      state.extras.noteText = note.value;
      update();
    };
    side.onclick = event => {
      const preset = event.target.closest("[data-preset]");
      if (preset) {
        const hidden = preset.dataset.preset === "reader" ? READER_HIDDEN_PARTS : DEFAULT_HIDDEN_PARTS;
        state.hiddenParts = new Set(hidden.filter(part => parts.includes(part)));
        syncChecks();
        update();
        return;
      }
      const all = event.target.closest("[data-all]");
      if (all) {
        state.excludedSections = all.dataset.all === "1" ? new Set() : new Set(info.sections.map(section => section.id));
        syncChecks();
        update();
        return;
      }
      // Pulsar el nombre de una sección la muestra en la vista previa.
      const label = event.target.closest("[data-action=goto]");
      if (label) {
        event.preventDefault();
        const id = label.dataset.target.split(":")[1];
        const target = frame.contentDocument?.querySelector(`[data-fps-head="${id}"]`) || frame.contentDocument?.querySelector(`[data-fps-sec~="${id}"]`);
        if (target) {
          target.scrollIntoView({ behavior: "smooth", block: "start" });
          target.classList.add("fps-flash");
          setTimeout(() => target.classList.remove("fps-flash"), 1200);
        }
      }
    };

    frame.onload = () => {
      const doc = frame.contentDocument;
      if (!doc) return;
      const flash = doc.createElement("style");
      flash.textContent = ".fps-flash { outline: 3px solid #f59e0b !important; outline-offset: 4px; transition: outline-color .3s; }";
      (doc.head || doc.documentElement).append(flash);
      // Enlaces del índice dentro de la vista previa: se desplaza en vez de navegar.
      doc.addEventListener("click", event => {
        const link = event.target.closest("a");
        if (!link) return;
        event.preventDefault();
        const id = link.dataset.fpsToc;
        if (id) doc.querySelector(`[data-fps-head="${id}"]`)?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
      update();
      // Los marcos internos cargan después: se les aplica la selección también.
      doc.querySelectorAll("iframe").forEach(inner => inner.addEventListener("load", update));
    };
    frame.srcdoc = previewHtml;

    const finish = value => {
      document.querySelector("#rv-cancel").onclick = null;
      saveButton.onclick = null;
      frame.onload = null;
      resolve(value);
    };
    document.querySelector("#rv-cancel").onclick = () => finish(null);
    saveButton.onclick = () => {
      const current = choices();
      if (info.sections.length && !includedSections(info, current).length) {
        error.textContent = t("err.nothingSelected");
        return;
      }
      finish(current);
    };

    update();
    setReviewVisible(true);
  });
}

// Vista previa de las páginas de un visor de PDF: devuelve las elegidas.
function openPagesReview({ pages }) {
  return new Promise(resolve => {
    const side = document.querySelector("#rv-side");
    const frame = document.querySelector("#rv-frame");
    const grid = document.querySelector("#rv-pages");
    const summary = document.querySelector("#rv-summary");
    const saveButton = document.querySelector("#rv-save");
    const error = document.querySelector("#rv-error");
    frame.hidden = true;
    grid.hidden = false;
    error.textContent = "";
    const selected = new Set(pages.map((_, index) => index));
    const extras = { cover: false, toc: false, links: false, note: false, noteText: "" };

    side.innerHTML = `
      <section class="rv-group">
        <div class="rv-group-head"><h3>${escapeHtml(t("rv.pages"))}</h3>
          <span><button type="button" class="rv-link" data-all="1">${escapeHtml(t("rv.all"))}</button> · <button type="button" class="rv-link" data-all="0">${escapeHtml(t("rv.none"))}</button></span>
        </div>
        <label class="rv-range"><span>${escapeHtml(t("rv.range"))}</span>
          <input id="rv-range" type="text" placeholder="${escapeHtml(t("rv.rangePlaceholder"))}" autocomplete="off"></label>
      </section>
      <section class="rv-group">
        <h3>${escapeHtml(t("rv.extras"))}</h3>
        ${checkboxRow({ id: "cover", label: t("ex.cover"), checked: false })}
        ${checkboxRow({ id: "note", label: t("ex.note"), checked: false })}
        <textarea id="rv-note" rows="3" placeholder="${escapeHtml(t("ex.notePlaceholder"))}" hidden></textarea>
      </section>`;

    grid.innerHTML = pages.map((page, index) => `
      <button type="button" class="rv-page is-on" data-index="${index}" aria-pressed="true">
        <img src="${page.dataUrl}" alt="">
        <span class="rv-page-check" aria-hidden="true">✓</span>
        <span class="rv-page-number">${escapeHtml(t("rv.pageN", { n: index + 1 }))}</span>
      </button>`).join("");

    const update = () => {
      grid.querySelectorAll(".rv-page").forEach(button => {
        const on = selected.has(Number(button.dataset.index));
        button.classList.toggle("is-on", on);
        button.setAttribute("aria-pressed", String(on));
      });
      summary.textContent = t("rv.pagesSummary", { n: selected.size, total: pages.length });
      saveButton.textContent = t("rv.savePdf");
    };
    const parseRange = value => {
      const result = new Set();
      for (const part of value.split(/[,;\s]+/).filter(Boolean)) {
        const [from, to] = part.split("-").map(Number);
        if (!from) continue;
        for (let n = from; n <= (to || from); n++) if (n >= 1 && n <= pages.length) result.add(n - 1);
      }
      return result;
    };

    grid.onclick = event => {
      const button = event.target.closest(".rv-page");
      if (!button) return;
      const index = Number(button.dataset.index);
      if (selected.has(index)) selected.delete(index);
      else selected.add(index);
      error.textContent = "";
      update();
    };
    side.onclick = event => {
      const all = event.target.closest("[data-all]");
      if (!all) return;
      selected.clear();
      if (all.dataset.all === "1") pages.forEach((_, index) => selected.add(index));
      update();
    };
    side.oninput = event => {
      if (event.target.id === "rv-range") {
        const range = parseRange(event.target.value);
        if (range.size) {
          selected.clear();
          range.forEach(index => selected.add(index));
          update();
        }
      } else if (event.target.id === "rv-note") {
        extras.noteText = event.target.value;
      }
    };
    side.onchange = event => {
      const input = event.target.closest("input[type=checkbox]");
      if (!input) return;
      extras[input.dataset.id] = input.checked;
      if (input.dataset.id === "note") side.querySelector("#rv-note").hidden = !input.checked;
    };

    const finish = value => {
      document.querySelector("#rv-cancel").onclick = null;
      saveButton.onclick = null;
      resolve(value);
    };
    document.querySelector("#rv-cancel").onclick = () => finish(null);
    saveButton.onclick = () => {
      if (!selected.size) {
        error.textContent = t("err.nothingSelected");
        return;
      }
      finish({ selected: [...selected].sort((a, b) => a - b), extras: { ...extras } });
    };

    update();
    setReviewVisible(true);
  });
}
