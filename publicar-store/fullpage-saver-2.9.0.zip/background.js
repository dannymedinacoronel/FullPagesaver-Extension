// Atajo de teclado (Ctrl+Mayús+O por defecto; se cambia en
// chrome://extensions/shortcuts): guarda la pestaña activa en PDF. La ventana
// de progreso usa el papel, la orientación y la velocidad elegidos por última
// vez en el popup.
chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command !== "save-pdf") return;
  const target = tab?.id ? tab : (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (!target?.id) return;
  const params = new URLSearchParams({ tab: String(target.id), mode: "pdf" });
  await chrome.windows.create({
    url: chrome.runtime.getURL(`save.html?${params}`),
    type: "popup",
    width: 440,
    height: 340,
    focused: true
  });
});
